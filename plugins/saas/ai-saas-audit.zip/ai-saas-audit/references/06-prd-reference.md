# Referenz 06: PRD-Struktur & AI-SaaS-spezifische Sections

Konsolidiert aus: "The definitive PRD template for AI-SaaS MVPs"

---

## PRD-Grundphilosophie für AI-SaaS

### Deterministic vs. Probabilistic
- Traditionelle PRDs: Input X → immer Output Y, binäre Pass/Fail-Kriterien
- AI-PRDs: Akzeptable Ranges, Thresholds, Fallback-Strategien
- Minimum / Target / Stretch statt Pass/Fail
- Continuous Monitoring statt One-Time QA
- Neue Risikokategorien: Halluzination, Drift, Bias, Regulatory Exposure

### Drei-Phasen-Struktur (Cross-Industry-Konsens)
1. **Problem Alignment** — Problem, Personas, Hypothese, Metriken
2. **Solution Alignment** — Scope, Stories, Flows, Risiken, Entscheidungen
3. **Launch Readiness** — AI/ML Specs, Architektur, Compliance, Rollout

### 10 Standard-Sections
Metadata, Problem Statement, Goals/Metrics, Personas, Solution, Scope/Non-Goals,
User Stories, Design/Mockups, Risks/Questions, Timeline

### AI-spezifische Zusatz-Sections (🤖)
- Model Strategy & Evaluation Matrix
- Prompt Engineering Specifications
- AI Safety & Guardrails (Input/Processing/Output)
- Hallucination Handling
- Feedback Loops & Continuous Improvement
- Model Versioning
- EU AI Act Classification
- Responsible AI Checklist

---

## MVP Scoping

### Philosophie
"What's the smallest thing that tests our riskiest assumption?"
Jedes Feature als testbare Hypothese: "We believe [X] and know we're right if [Y]"

### MoSCoW-Constraint
- **Must-Have**: ≤60% des Aufwands
- **Should-Have**: ~20%
- **Could-Have**: ~20%
- **Won't-Have**: Explizit dokumentiert (verhindert Scope Creep)

### Story Mapping
User Journey horizontal, Stories vertikal → MVP = dünnste vollständige E2E-Erfahrung.
MVP ≠ weniger Features, sondern kohärente, minimale Experience.

---

## Metriken-Framework

### Drei Ebenen
1. **Primary Metrics (must move)**: Baseline, MVP Target, Stretch Target, Measurement
2. **Secondary Metrics (should move)**: Baseline, Target, Measurement
3. **Guardrail Metrics (must not regress)**: Current, Minimum, Alert Threshold

### AI Model Metrics
| Metrik | Min | Target | Stretch |
|--------|-----|--------|---------|
| Accuracy / F1 | [X] | [Y] | [Z] |
| Hallucination Rate | <[X%] | <[Y%] | <[Z%] |
| Latency P95 | <[X ms] | <[Y ms] | <[Z ms] |
| Cost per Interaction | <$[X] | <$[Y] | <$[Z] |
| Guardrail Bypass Rate | <[X%] | 0% | 0% |

### Abort Conditions
Definiert vor Rollout. Beispiel: PII Exposure >0.1% → automatischer Rollback.

---

## Acceptance Criteria für AI-Features

### Given/When/Then Format (erweitert)
```gherkin
Scenario: AI-specific behavior
  Given user provides input to AI feature
  When AI generates response
  Then response meets quality threshold
  And confidence indicator is displayed
  And user can provide feedback via thumbs up/down
```

### Definition of Done (AI-erweitert)
- [ ] Code reviewed
- [ ] Unit + Integration Tests (≥80% Coverage)
- [ ] AI Evaluation Suite passing (alle Metriken über Minimum)
- [ ] Keine Critical/High Bugs
- [ ] Accessibility (WCAG 2.1 AA)
- [ ] Dokumentation aktualisiert
- [ ] Product Owner reviewed
- [ ] Staging deployed und Smoke-tested

---

## Edge Cases & Error Handling

| Szenario | Verhalten | User-Facing Message |
|----------|----------|-------------------|
| AI Timeout | Cached/Fallback Response | "Dauert länger als üblich. Hier ist was wir haben..." |
| Confidence unter Threshold | Human Review | "Lasse einen Spezialisten draufschauen." |
| Rate Limit | Queue + Cache | "Hohe Nachfrage. Anfrage in Warteschlange." |
| Malicious Input | Block + Log | "Kann diese Anfrage nicht verarbeiten." |
| Leere Ergebnisse | Graceful Empty State | "Keine Ergebnisse. Versuche andere Filter." |
| Netzwerkfehler mid-Op | Draft speichern | "Verbindung verloren. Fortschritt gespeichert." |

### Standardisiertes Error Response Format
```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Human-readable description",
    "details": [{"field": "email", "issue": "Invalid format"}],
    "request_id": "uuid",
    "documentation_url": "https://docs.product.com/errors/..."
  }
}
```

---

## Rollout-Phasen

### Phase 0: Model Validation (Pre-Alpha)
- Offline Eval gegen Test Sets
- Benchmark vs. Baselines
- Ethics/Bias Review
- Data Pipeline E2E validiert
- Cost Projections bestätigt
- **Gate**: Alle AI-Metriken über Minimum

### Phase 1: Internal Alpha (Dogfooding)
- Nur internes Team
- Feature Flag: `internal_only`
- Monitor: Latency, Accuracy, Edge Cases, Cost
- **Gate**: Keine Critical Bugs, Team-Confidence in UX

### Phase 2: Closed Beta
- X% der Nutzer oder spezifisches Segment
- Feature Flag: 5-10%
- A/B Test: Control vs. Treatment
- **Gate**: Statistische Signifikanz, keine Guardrail-Regressionen

### Phase 3: Open Beta
- 25-50% der Nutzer
- Segmentierungs-Analyse: Performance konsistent über Gruppen
- **Gate**: Confidence in Results at Scale

### Phase 4: General Availability
- 50% → 75% → 100% über 3-7 Tage
- Continuous Monitoring, Retrain-Trigger aktiv
- Beta-Switch: Nutzer können zurückschalten, Opt-Out tracken

---

## Rollback

### Trigger
| Trigger | Typ | Aktion |
|---------|-----|--------|
| Error Rate > X% | Automatisch | Feature Flag disable |
| AI Latency P95 > X ms | Automatisch | Fallback Model/Cache |
| Safety Violation | Automatisch | Kill Switch |
| PII Exposure > 0.1% | Automatisch | Kill Switch + Incident |
| User Satisfaction < X | Manuell | Pause + Investigate |
| Cost > $X/Tag | Manuell | Reduce Rollout % |

### SLA
Detect + Decide + Disable ≤ 10 Minuten

---

## Feature Flags

| Flag | Zweck | Default |
|------|-------|---------|
| `[feature]_enabled` | Master Kill Switch | `false` |
| `[feature]_percentage` | Rollout % | `0` |
| `[feature]_model_version` | Model Version Control | `v1.0` |
| `[feature]_fallback` | Fallback Mode | `true` |

---

## Model Versioning

| Artefakt | Tool | Konvention |
|----------|------|-----------|
| Model Weights | MLflow / W&B / DVC | Semantic Versioning |
| Prompts | Git / Prompt Registry | Semantic Versioning |
| Training Data | DVC / Delta Lake | Date-stamped Snapshots |
| Eval Datasets | Git LFS / Cloud | Version-tagged |
| Config | Git | Tied to Deployment |

### Retraining-Trigger
- Accuracy unter Threshold für Y Tage
- Data Drift (PSI > Threshold)
- Neue Trainingsdaten > X Records
- Scheduled Quarterly Refresh

---

## Feedback & Continuous Improvement

### Detect → Diagnose → Decide → Deploy
```
Auto-Eval auf Prod Logs → Trace Replay → Gate Metrics → Ship mit Observability
```

### Data Collection
- Log: Inputs, Outputs, Timestamps, Latency, Tokens, Feedback
- PII anonymisieren vor Storage
- 0.5-1% Production Sample für Weekly Eval
- Implizite Signale: Accept/Reject, Conversation Abandonment

### Improvement-Kadenz
| Aktivität | Frequenz |
|-----------|----------|
| In-the-wild Eval Review | Weekly |
| Human Review Sample Outputs | Monthly |
| Bias/Fairness Audit | Quarterly |
| Drift Detection | Automated/Continuous |
| Retraining Trigger Review | Monthly |

---

## Non-Functional Requirements Benchmarks

### Performance
| Metrik | Target | Maximum |
|--------|--------|---------|
| LCP Landing Page | ≤1.5s | ≤2.5s |
| Dashboard Load | ≤3.0s | ≤5.0s |
| API Read P95 | ≤200ms | ≤500ms |
| API Write P95 | ≤500ms | ≤1000ms |
| AI TTFT | ≤500ms | ≤1000ms |
| AI Throughput | ≥40 tok/s | ≥20 tok/s |

### Availability
| Tier | SLA | Downtime/Monat |
|------|-----|---------------|
| Internal SLO | 99.95% | 21.9 min |
| Public SLA | 99.9% | 43.8 min |
| AI Features SLO | 99.5% | 3.65 h |

### Disaster Recovery
- RPO ≤1 Stunde
- RTO ≤4 Stunden
