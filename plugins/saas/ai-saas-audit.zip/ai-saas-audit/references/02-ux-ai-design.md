# Referenz 02: UX & AI Interaction Design

Konsolidiert aus: "AI-SaaS Design-Manifest" §1 (Design-Prinzipien)

---

## Fünf Kernprinzipien für AI-First Design

### 1. AI als Vorsprung, nicht als Ersatz
- AI liefert Entwürfe, Empfehlungen, Analysen — finale Entscheidung beim Nutzer
- Draft-basierte Interfaces mit Edit-Kontrollen statt Black-Box-Automatisierung
- Accept/Adjust/Reject Controls als Kerninteraktionsmuster

### 2. Konfidenz-Signalisierung als Pflicht
- Jeder AI-Output mit Zuverlässigkeitsindikatoren: Confidence Scores, Quellen, Reasoning-Panels
- Interface signalisiert explizit, wie sicher das System ist
- Nicht jeden Output als Fakt präsentieren

### 3. Passgenau erklären
- Zu viel Erklärung = Rauschen
- Einklappbare Reasoning-Panels oder Zitat-Links
- Richtige Ebene hängt vom Nutzerkontext ab

### 4. Aufsicht ohne Reibung
- Review/Oversight notwendig, aber nicht als Mehrarbeit
- Inline-Review-Tools, kontextuelle Reasoning-Displays
- Überprüfung als natürlicher Workflow-Teil

### 5. Variabilität normalisieren
- AI-Ergebnisse als Vorschläge rahmen, nicht als Fakten
- Sprache und UI setzen Erwartungen (Outputs variieren)
- Regeneration-Controls und Versionshistorie als Kernfeatures

---

## Framework-Synthese: Was alle fordern

| Prinzip | Google PAIR | Microsoft HAX | Apple HIG | Anthropic | NN/g |
|---------|------------|---------------|-----------|-----------|------|
| Transparenz/Erklärbarkeit | 5 Patterns | G1, G2, G11 | Clarity | Constitutional AI | ✓ |
| Nutzerkontrolle | 5 Patterns | G7, G8, G9, G17 | Corrections | Steerable AI | ✓ |
| Vertrauenskalibrierung | 7 Patterns | G2, G10 | Criticality | Safety-first | ✓ |
| Fehlerbehandlung | 3 Patterns | G10, G12 | Mistake handling | Self-correction | ✓ |
| Feedback-Mechanismen | ✓ | G15 | Input patterns | RLHF | ✓ |
| Datenschutz | ✓ | G6 | Always protect | Data governance | ✓ |

### B2B-Prioritäten
- Oversight-Workflows, Audit Trails, Confidence-Indikatoren, rollenbasierte Kontrollen
- a16z: Bei B2B von Chat-UX weggehen — Chat trennt Nutzer vom Workflow

### Consumer-Prioritäten
- Simplizität, Progressive Disclosure, Retention-fokussiertes Design

### Für beide
- Transparenz, Graceful Degradation, HITL als nicht verhandelbar

---

## Google PAIR Guidelines: 23 Patterns

Sechs Schlüsselfragen:
1. Ob AI Mehrwert bietet
2. Wie man das System erklärt
3. Wie man Datensätze verantwortungsvoll erstellt
4. Wie Nutzer Vertrauen kalibrieren
5. Balance zwischen Kontrolle und Automatisierung
6. Wie man bei Fehlern unterstützt

- 7 Patterns für Vertrauenskalibrierung
- 5 Patterns für User Control vs. Automatisierung
- Tools: Data Cards Playbook (18 Transparenz-Patterns), Model Cards

---

## Microsoft HAX Toolkit: 18 Guidelines

### Initial (Erwartungen setzen)
- Klar kommunizieren was das System kann und wie gut
- Übertreiben schadet der Wahrnehmung nachhaltig

### Während der Interaktion
- Kontextrelevante Infos zeigen, soziale Normen respektieren
- Biases mitigieren, effiziente Invokation/Dismissal
- Korrekturen vereinfachen, bei Unsicherheit gracefully degradieren
- Entscheidungen transparent erklären

### Bei Fehlern
- Jüngste Interaktionen merken, aus Verhalten lernen
- Updates vorsichtig einspielen, granulares Feedback ermöglichen

### Über die Zeit
- Konsequenzen vermitteln, globale Kontrollen bereitstellen
- Über Verhaltensänderungen informieren

---

## Apple HIG: ML nach 5 Dimensionen

| Dimension | Spektrum | Design-Implikation |
|-----------|---------|-------------------|
| Kritikalität | Komplementär → Kritisch | Je kritischer, desto höhere Zuverlässigkeit |
| Datensensitivität | Niedrig → Hoch (Gesundheit) | Höhere Privacy-Anforderungen |
| Proaktivität | Nutzer-initiiert → Unaufgefordert | Proaktives bedarf höherer Precision |
| Sichtbarkeit | Unsichtbar → Sichtbar | Sichtbares bedarf Erklärbarkeit |
| Dynamik | Statisch → Kontinuierlich lernend | Dynamisches bedarf Benachrichtigung |

---

## Progressive AI Disclosure

### Prinzipien
- Komplexität schrittweise enthüllen
- Einfache Features zuerst, fortgeschrittene bei Bedarf
- Maximal 2-3 Ebenen (mehr = Frustration)
- Klare Indikation für Zugang zu mehr Optionen
- Tailoring nach Nutzersegment

### Drei-Schichten-Modell (2025/2026)
- **Layer 1 (Index)**: Leichtgewichtige Metadaten
- **Layer 2 (Details)**: Vollständiger Content bei Relevanz
- **Layer 3 (Deep Dive)**: Unterstützungsmaterial bei vertiefter Analyse

---

## Graceful Degradation

### Pflicht-Elemente
- Klartext-Fehlermeldungen statt technischer Codes
- Bestätigung dass Nutzerarbeit gespeichert
- 2-3 Recovery-Optionen (Retry, Warten, Offline-Modus)
- Warme Farben (Amber/Gelb) statt aggressivem Rot
- Funktionierende Basis-Features bei AI-Ausfall
- Nutzerkontext über Fehler hinweg bewahren

### Gute Beispiele
- ChatGPT: Räumt Unsicherheit ein
- Google Translate: Bietet Alternativen an

---

## Trust Calibration

### Kernproblem
Nature (2024): Über-Vertrauen in AI verursacht ernsthafte Safety-Probleme.
Menschenähnlichere Systeme steigern Vertrauen über tatsächliche Fähigkeiten hinaus.
Traditionellere HCI-Patterns können AI sicherer machen.

### Vor der Interaktion (am wirksamsten)
- Explizite Erwartungen über Fähigkeiten und Limitierungen
- Performance-Statistiken zeigen
- Outputs als "Analyse suggests" statt "I think" (Tool-Sprache)
- Exakte Confidence-Prozentsätze statt menschenartigen Hedgings

### Während der Interaktion
- Performance-orientierte Signale (was das System kann)
- Prozess-orientierte Signale (wie es arbeitet)
- Confidence Scores neben Outputs
- Unsicherheitsbereiche explizit hervorheben

### Kritische Erkenntnis (FAccT 2024)
Erste Eindrücke formen Vertrauen persistent — in frühen Phasen etabliertes
Vertrauen beeinflusst Einschätzung unabhängig von späterer AI-Accuracy.
→ Von Anfang an richtig kalibrieren.

---

## UX-Benchmarks für SaaS

### Technische UX-Anforderungen
- API-Antwortzeiten <200ms (P95)
- Seitenladezeiten <2 Sekunden
- Streaming wahrgenommen als 40% schneller (selbst bei identischer Gesamtzeit)

### Design-Standards 2024-2025
- 71% der Nutzer erwarten personalisierte Erfahrungen
- AI-gestützte Personalisierung wächst >75% jährlich
- Micro-Interactions steigern Zufriedenheit um ~25%
- WCAG-2.2-Barrierefreiheit = 35% größere Reichweite
- 78% implementieren eingebettete Dashboards
- Investitionen in UX erzielen bis zu 9.900% ROI
- Schlechte UX führt zu 70% Churn
