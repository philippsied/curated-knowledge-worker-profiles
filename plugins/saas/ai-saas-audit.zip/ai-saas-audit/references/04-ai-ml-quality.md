# Referenz 04: AI/ML Core — RAG, Agents, Model Strategy, Evaluation

Konsolidiert aus: "AI-SaaS Design-Manifest" §2 (RAG, Agents), §3 (Workflow-Module), §4 (Qualität)

---

## RAG-Architektur: Reifeleiter

| Level | Eignung | Performance |
|-------|---------|-------------|
| **Naive RAG** | Nur Prototypen | 10-40% Erfolgsrate in Enterprise |
| **Advanced RAG** | **2025-Produktionsstandard** | +15-30% Retrieval-Accuracy (Hybrid Search) |
| **Graph RAG** | Beziehungsqueries | 99% Precision, hohe Komplexität |
| **Agentic RAG** | Wenige Spezialfälle | Agent nutzt Retrieval als Tool unter vielen |

### Advanced RAG Komponenten (Produktionsstandard)
- **Hybrid Search**: Vektor + BM25 via Reciprocal Rank Fusion → +15-30%
- **Cross-Encoder Reranking**: +23,4% (BEIR mit Cohere Rerank 3.5), 50-100ms Latenz
- **Query Transformation**: HyDE → +20-35% bei mehrdeutigen Queries
- **Parent Document Retrieval**: Kleine Chunks matchen, große liefern Kontext

### Empfehlung
Die meisten Enterprise-Apps brauchen Advanced RAG. Einige rechtfertigen GraphRAG. Wenige brauchen Agentic. Nicht über-engineeren.

---

## Agent-Architekturen

72% der Enterprise-AI-Projekte (2025) involvieren Multi-Agent-Architekturen.

### Framework-Landschaft
| Framework | Stärke | Limitation |
|-----------|--------|-----------|
| **LangGraph** | Produktionsstandard, Stateful Graph, Cycles | ThoughtWorks: "Hold" für LangChain |
| **CrewAI** | Schnellstes Prototyping, 60% Fortune 500 | Ceiling bei 6-12 Monaten |
| **OpenAI Agents SDK** | Production-Ready Handoffs | OpenAI-Ökosystem |
| **Pydantic AI** | ThoughtWorks-empfohlen für Production Python | Jünger |

### Entscheidungsregel
- **Single Agent**: Workflow = primär ein Agent mit Tools
- **Multi-Agent**: Workflow ist genuinely multi-role
- "Start simple, scale smart"

---

## Workflow-Module (10 Kernmodule)

```
Ingestion → RAG/Knowledge → Prompt Templates
    ↓            ↓                 ↓
    → AI Orchestration ← Safety (Input Guards)
            ↓
    Evaluation ← Monitoring
            ↓
    Safety (Output Guards) → HITL Review
            ↓                    ↓
    Output Formatting → Feedback & Annotation
            ↓
    Monitoring → Prompt (Improvement Signals)
```

### Ingestion/Data Pipeline
- Optimale Chunk-Größe: 300-500 Tokens
- SPLICE-Methode: +27% Answer Precision
- Semantisches Chunking: +9% Recall vs. Fixed-Size
- Tools: LlamaParse, Unstructured.io, LangChain Loaders
- Vektor-DBs: Pinecone (Zero-Ops), Weaviate (Hybrid), Milvus (Milliarden), pgvector (<5M)

### Prompt Template Management
- Zentral, versioniert, getestet, deployed als immutable Artefakte
- Entkoppelt von Code-Deployments
- Non-Technical Users (PMs, Domain Experts) können editieren und testen
- Environment-Management: Dev/Staging/Production mit Promotion-Gates
- Tools: Langfuse, LangSmith Hub, PromptLayer, Braintrust

### AI Orchestration
- Chains (sequentiell), Agents (autonom: ReAct, Plan-and-Execute)
- Tool Integration via Schema-basierte Function Calls
- State Management mit Thread Persistence + Checkpointing = kritisch
- Gängig: LlamaIndex (Retrieval) + LangGraph (Orchestration)

### Feedback & Annotation
- **Explizit**: Thumbs Up/Down, Korrekturen, Bewertungen
- **Implizit**: Konversationslänge, Task Completion, Return-Frequenz, Edit-Distance
- RLHF Pipeline: Preference Data → Reward Model → DPO
- Tools: LangSmith Annotation Queues, Argilla, Label Studio

### Output Formatting & Delivery
- Schema Enforcement (JSON/Pydantic)
- Template Rendering (Markdown, HTML, Email)
- Streaming-Support
- Citation Injection, Confidence Display
- "Ich weiß es nicht"-Handling

---

## Model Selection: Multi-Model-Strategie

### Drei Tiers
| Tier | Einsatz | Beispiele |
|------|---------|-----------|
| Günstig | Routing, einfache Tasks | GPT-4o-mini, Gemini Flash |
| Mid-Tier | Moderates Reasoning | Claude Sonnet, GPT-4o |
| Premium | Komplexes Multi-Step-Reasoning | Claude Opus, o3 |

### Model Fallback Chain
Primary → Secondary → Tertiary über verschiedene Provider für Resilienz.

### Open-Source
- Performance-Lücke zu Proprietary: nur 0,3 PP auf MMLU
- 89% der Organisationen nutzen Open-Source-AI
- 25% höherer ROI als Proprietary-Only

---

## Sieben Qualitätsdimensionen

| Dimension | Zielwert | Messmethode |
|-----------|---------|-------------|
| **Accuracy** | >90% (Enterprise) | LLM-as-Judge, Fact-Checking |
| **Faithfulness** | >0.85 Score | RAGAS, DeepEval |
| **Relevance** | Kontextabhängig | Semantic Similarity, RAGAS |
| **Latency** | <2s TTFT, <5s total | P50/P95/P99 Monitoring |
| **Consistency** | <10% Varianz | SCORE Framework, Multi-Run |
| **Safety** | >99% Compliance | NeMo Guardrails, Toxicity Classifiers |
| **Kosteneffizienz** | Use-Case-spezifisch | Cost per successful task |

---

## Halluzinations-Management

### Kosten: >$67,4 Mrd. Verluste (2024)

### Strategien zur Inference-Zeit
- RAG (verbreitetster Ansatz, eliminiert nicht vollständig)
- Chain-of-Thought-Prompting (logische Kohärenz)
- Self-Consistency (mehrere Paths, Mehrheitsvotum)
- Prompt-Kalibrierung: GPT-4o von 53% auf 23% Halluzination
- Abstention Training ("Ich weiß es nicht")

### In Produktion
- Kontinuierliches Fact-Checking gegen Knowledge Bases
- Confidence-Score-Anzeige für Nutzer
- Span-Level-Verification in RAG-Pipelines
- Beste Detection Tools: 90-91% Accuracy (W&B Weave, Arize Phoenix)

---

## Testing nicht-deterministischer Outputs

### Fundamentale Trennung
- **Deterministische Schicht** (Data Fetching, Prompt Assembly, Schema Validation): Klassisch testen
- **Nicht-deterministische Schicht** (Model Output): Probabilistisch testen

### Ansätze
- **Probabilistische Pass Rates**: N Runs, "passt X% der Runs"
- **Dimensionen statt Werte**: Accuracy, Coverage, Tone, Format, Constraint Adherence — auf Rubrik-Skala
- **LLM-as-Judge**: Stärkeres Modell als Judge matcht menschliches Urteil ~80%. Mehrere Judges als "Jury"

### Vier-Schichten-Testarchitektur
1. **Unit Tests**: LLM-Responses mocken, deterministische Logik
2. **Integration Tests**: Echte LLM-Calls, Format/Schema prüfen
3. **Evaluation Tests**: Kuratierte Datasets, automatisierte Metriken
4. **Shadow Testing**: Neuer Prompt parallel zu Production, ohne User-Risiko

### Evaluation Frameworks
| Tool | Stärke |
|------|--------|
| RAGAS | 5 Kern-Metriken referenzfrei |
| DeepEval | 60+ Metriken mit Selbsterklärung |
| Promptfoo | Lokal, Security-Testing, CI/CD |

---

## User-facing Quality Metrics

| Metrik | Ziel | Was sie misst |
|--------|------|---------------|
| CSAT | Hoch | Post-Interaction Satisfaction |
| Task Completion Rate | >80% | Erfolgreiche Aufgabenabschlüsse |
| Trust Score | Steigend | Korreliert mit Transparenz-Features |
| Escalation Rate | <20% | Häufigkeit menschlicher Übernahme |
| Error Discovery Rate | <5% | Nutzer-entdeckte Fehler |

**Best Practice**: Automatisierte Quality Metrics (RAGAS/DeepEval auf Production Traffic) + User-Facing Metrics + Business Metrics (Cost per Resolution, Deflection Rate).

---

## Data Flywheel

### Kreislauf
Produkt → Feedback → Modell verbessern → Mehr Nutzer → Mehr Feedback → Compound Improvement

### NVIDIAs 6 Stufen
1. Production Data erfassen
2. Training Signals kuratieren
3. Kandidatenmodelle fine-tunen
4. Rigoros evaluieren
5. Nahtlos deployen
6. Intrinsisches + extrinsisches Feedback sammeln

### Agent-in-the-Loop Framework (2025)
4 Annotations-Typen in Live-Ops:
- Pairwise Response Preferences
- Agent Adoption Decisions
- Knowledge Relevance Checks
- Missing Knowledge Identification

Ergebnisse: +11,7% Recall, +14,8% Precision, +8,4% Helpfulness.
Retraining von Monaten auf Wochen reduziert.
