# Referenz 01: Product Strategy, PMF & SaaS Metrics

Konsolidiert aus: "Der Bauplan für ein erstklassiges SaaS-Produkt"

---

## Product-Market Fit

### Messung
- **Sean-Ellis-Test**: "Wie enttäuscht wärst du ohne dieses Produkt?" — ≥40% "sehr enttäuscht" = PMF
- Validiert durch ~100 Startups. Slack erreichte 51% bei 731 Nutzern
- **Superhuman-Methode**: Segmentierung auf High-Expectation Customers. Roadmap 50/50: Was Fans lieben verdoppeln / Was Zögernde zurückhält beheben

### Ergänzende PMF-Indikatoren (a16z, Sacks, Rachitsky)
- Monatliche Churn <2%
- Klarer Pfad zu 100K USD MRR
- DAU/MAU >40-45% bei Kernkunden
- >30% Neukunden über organische Kanäle
- Flach werdende Retention-Kurven in Kohorten

### PMF-Bestätigung (3 Signale gleichzeitig)
1. Sean-Ellis ≥40% bei mind. 40 Befragten
2. Flache Retention-Kurven (Week-1 bester Langzeit-Prädiktor)
3. >50% neue Accounts über organische/Direkt-Traffic-Kanäle

### Falsche PMF-Signale
- Wachstum rein durch Paid Acquisition
- Early-Adopter-Begeisterung ohne Mainstream-Transfer
- Hoher NPS bei sinkender Nutzung
- NRR 100% die 20% Churn durch 20% Expansion maskiert

---

## Pricing & Monetarisierung

### Kernfakten
- 1% Pricing-Verbesserung = 12,7% mehr Profit (stärkster Hebel)
- 78% setzen auf wertbasiertes Pricing
- 61% nutzen Hybrid-Pricing (Per-User + Usage) — +34% höhere LTV/CAC-Ratio
- 86% der SaaS >100M USD nutzen ≥3 Preisdimensionen
- Jährliche Verträge senken Churn um Faktor 3-5

### Modelle 2025
| Modell | Verbreitung | Benchmark |
|--------|------------|-----------|
| Per-User | 57% (rückläufig) | Median 45 USD/Monat |
| Hybrid (Per-User + Usage) | 61% (steigend) | +34% LTV/CAC |
| Usage-Based-Elemente | 43% | +8 PP vs. 2024 |
| Freemium | 38% | 8-12% Conversion zu Paid |
| Flat-Rate | 14% (stark rückläufig) | -25% YoY |

### Freemium Trade-off
- 140% höhere Visitor-to-Signup-Conversion als Free Trials
- 30-50% höhere Supportkosten pro zahlendem Kunden

---

## Onboarding & Time-to-Value

### Kernfakten
- 8/10 Nutzer verlassen Apps wegen Unverständnis
- Keine Aktivierung in 3 Tagen = 90% Churn-Wahrscheinlichkeit
- TTV-Halbierung kann langfristige Retention verdoppeln
- Jede zusätzliche Minute TTV senkt Conversion um 3%

### 3-Phasen-Framework
1. **0-60 Sekunden**: Orientierung (Willkommen, Rollenauswahl, Erwartungen)
2. **1-5 Minuten**: Aktivierung (geführter Walkthrough zum ersten Wertmoment)
3. **5min - 7 Tage**: Verstärkung (Checklisten, Tooltips, E-Mail-Sequenzen)

### Benchmarks
- 3-Schritte-Tours: 72% Completion (vs. 16% bei 7 Schritten)
- Personalisierte Flows: +30% 7-Tage-Retention
- Top-Quartil: 2,3x höhere Aktivierung als Median

---

## Product-Led Growth

### Kernfakten
- 58% der B2B-SaaS betreiben PLG
- PLG = 15-20% höhere NRR als rein Sales-getrieben
- PQLs konvertieren mit 25-30% (5-6x MQL-Rate)
- Zukunft = Hybrid: PLG für Acquisition, Sales für Enterprise

### Referenzbeispiele
- Canva: Product-Led SEO → 260M MAU, 3,5B USD ARR
- Notion: 100M+ Nutzer
- Figma: >1B USD Jahresumsatz

### Community als Multiplikator
- Integrierte Ökosysteme → 40% bessere Retention
- Beispiele: Figma CONFIG, Notion Templates, Salesforce AppExchange

---

## Customer Success & Retention

### NRR ist der mächtigste Wachstumshebel
- NRR >100% = organisches Wachstum ohne Neukunden-Abhängigkeit
- NRR >120% = 2-3x höhere Bewertungen
- Bei >50M USD ARR übertrifft Expansion den Neukunden-Umsatz

### Benchmarks 2024-2025
| Segment | Median NRR | Median GRR |
|---------|-----------|-----------|
| Enterprise | 118% | >95% |
| Mid-Market | 108% | ~92% |
| SMB | 97% | ~85% |

### Retention-Strategien
- AI-Churn-Scoring: 10-15% Reduktion über 18 Monate
- Proaktive Health Scores: 6-12 Punkte NRR-Lift
- Involuntary-Churn-Recovery: 70% des verlorenen Umsatzes zurückgewonnen
- Upgrade-Trigger bei 80% der Tier-Grenzen
- 5% Churn-Reduktion kann Wachstumsrate verdoppeln

---

## Quantitative Benchmarks

| Metrik | Gefahr | Akzeptabel | Gut | Exzellent |
|--------|--------|-----------|-----|-----------|
| Sean-Ellis | <25% | 25-35% | 40-50% | >50% |
| NPS | <0 | 0-36 | 36-50 | >50 |
| Monatl. Churn (B2B) | >5% | 3-5% | 1-3% | <1% |
| NRR | <90% | 90-100% | 100-110% | >120% |
| LTV:CAC | <1:1 | 1:1-3:1 | 3:1-5:1 | >5:1 |
| CAC Payback | >24 Mo | 12-18 Mo | 6-12 Mo | <6 Mo |
| DAU/MAU | <10% | 10-20% | 25-40% | >50% |
| Gross Margin | <70% | 70-75% | 75-80% | >85% |
| Rule of 40 | <20% | 20-30% | 30-40% | >40% |
| Burn Multiple | >3x | 2-3x | 1-2x | <1x |

---

## Red Flags (sofortige Handlung)
- Monatliche Churn >5% (46% jährlicher Verlust)
- NRR <90% (aktive Revenue-Kontraktion)
- GRR <85% (Produktbasis erodiert)
- LTV:CAC <1:1 (Wertvernichtung)
- CAC Payback >24 Monate
- Burn Multiple >3x
- Trial Conversion <5%
- Retention-Kurve fällt gegen null (kein PMF)

---

## Die 5 tödlichsten Anti-Patterns

1. **Premature Scaling**: Erst Business Model validieren, dann skalieren. Founder-Led Sales muss funktionieren vor VP Sales.
2. **Feature Bloat**: 40-60% Trial-Nutzer nutzen Produkt genau einmal. Progressive Disclosure + RICE + Nein sagen.
3. **Leaky-Bucket-Syndrom**: Retention-Kurve fällt → Alle Wachstumsausgaben stoppen, Core-Value-Loop reparieren.
4. **Falsches Pricing**: 30% höhere Wachstumsraten bei regelmäßiger Pricing-Optimierung. Wertbasiert = 40% niedrigere Churn.
5. **Organisatorische Fehler**: Zu generischer Markt, keine Differenzierung. Vertikal + AI-native performen signifikant besser.

---

## Operative Frameworks

### AARRR (Pirate Metrics)
Acquisition → Activation → Retention → Revenue → Referral
Für etablierte Produkte: **RARRA** (Retention zuerst)

### T2D3 Wachstumspfad
Bei ~2M USD ARR: Triple → Triple → Double → Double → Double = 144M USD ARR in 5 Jahren

### North Star Metric
Muss: Revenue treiben + Kundenwert reflektieren + Fortschritt messen
Beispiele: Slack = "Nachrichten/DAU", HubSpot = "neue Kontakte", Dropbox = "Uploads in erster Stunde"

### Puls-Check-Kadenz
- **Wöchentlich**: DAU/WAU, Signups, Aktivierung, Feature-Nutzung, Support-Tickets, Churn-Signale
- **Monatlich**: MRR-Zusammensetzung, NRR, GRR, Kohorten, NPS, LTV:CAC, Trial-Conversion
- **Quartalsweise**: Rule of 40, Magic Number, Sean-Ellis Survey, Pricing-Review
