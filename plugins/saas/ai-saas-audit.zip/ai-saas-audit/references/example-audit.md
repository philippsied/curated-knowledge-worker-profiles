# Beispiel-Audit-Report: "TaskPilot AI" (fiktiv)

Dieses Beispiel zeigt die erwartete Qualität und Struktur eines Audit-Reports.
Es basiert auf einer fiktiven MVP-Spezifikation für ein AI-gestütztes
Projektmanagement-Tool. Nutze es als Referenz für Ton, Detailtiefe und Format.

> **Hinweis für den Auditor:** Die Kommentare in `[Annotation: ...]` erklären
> warum bestimmte Bewertungen so ausgefallen sind. Sie gehören NICHT in einen
> echten Audit-Report.

---

## Teil 1: Executive Summary

**Gesamtscore: 38 / 96 (40%) — 🟠 Developing**

**Reifegrad:** 🟠 Developing — Grundlagen erkennbar, aber erhebliche Lücken
in AI-spezifischen Bereichen (Safety, Evaluation, HITL) und fehlende
Compliance-Vorbereitung.

**Top-3 Stärken:**
1. Klare Problemdefinition mit 25 Discovery-Interviews und validiertem ICP
2. Solide technische Architektur-Entscheidung (Modular Monolith + separater Inference-Service)
3. Gut definiertes Onboarding mit messbarem "Aha-Moment" (erstes AI-generiertes Projektsummary)

**Top-3 kritische Gaps:**
1. Keine Guardrails spezifiziert (weder Input noch Output) — Launch-Blocker
2. Keine Evaluation/Testing-Strategie für AI-Outputs definiert
3. EU AI Act Klassifikation fehlt vollständig trotz Datenverarbeitung in der EU

**Gesamteinschätzung:** TaskPilot hat eine starke Produkt-Vision und solide
SaaS-Grundlagen, behandelt AI aber wie einen deterministischen Feature-Layer.
Die Spec adressiert keines der AI-spezifischen Risiken (Halluzination,
Prompt Injection, Confidence-Kalibrierung) und hat keinen Plan für
Human-in-the-Loop. Vor einem Beta-Launch müssen die Safety- und
Compliance-Lücken geschlossen werden.

---

## Teil 2: Phasen-Detail-Scores

### Phase 1: Strategic Foundation
**Phasen-Score: 2.3 / 3.0**

| Bereich | Score | Bewertung |
|---------|-------|-----------|
| 1.1 Problem & Market | 🟢 3 | 25 Interviews, ICP definiert (Mid-Market PM-Teams, 20-200 MA), JTBD-Framework angewendet, Wettbewerbsmatrix vorhanden |
| 1.2 Pricing | 🟡 2 | Hybrid-Pricing (Per-Seat + AI-Credits) definiert mit 3 Tiers. Aber: AI-Kosten pro Interaktion nicht kalkuliert, kein Usage-Based-Pricing für AI-Heavy-Nutzung |
| 1.3 North Star Metric | 🟡 2 | "Projekte mit AI-Summary pro Woche" als NSM, MRR und Churn getrackt. Aber: Keine Guardrail-Metriken, keine Leading/Lagging-Unterscheidung |

[Annotation: Phase 1 ist die stärkste weil das Team offensichtlich Product-Discovery ernst nimmt. Der Score von 2 bei Pricing reflektiert dass AI-Kosten nicht durchkalkuliert sind — bei einem AI-SaaS-Produkt ein P1-Item.]

---

### Phase 2: AI/ML Core
**Phasen-Score: 1.4 / 3.0**

| Bereich | Score | Bewertung |
|---------|-------|-----------|
| 2.1 Model Strategy | 🟡 2 | Claude Sonnet als Primary, GPT-4o-mini als Fallback. Evaluation Matrix mit 3 Modellen. Aber: Kein Multi-Tier-Routing, kein Vendor-Lock-in-Assessment |
| 2.2 RAG & Knowledge | 🟠 1 | "Vektor-DB für Projektdaten" erwähnt, aber kein RAG-Level spezifiziert, keine Chunking-Strategie, kein Reranking |
| 2.3 Prompt Engineering | 🟠 1 | System-Prompt im Dokument enthalten, aber nicht versioniert. Kein dediziertes Verzeichnis. Keine Temperature-Begründung |
| 2.4 Agent & Orchestration | 🟡 2 | Single-Agent-Entscheidung dokumentiert mit Begründung. LangGraph als Framework. Kein Checkpointing erwähnt |
| 2.5 Evaluation & Testing | 🔴 0 | Nicht adressiert. Kein Eval-Framework, kein Golden Dataset, keine Teststrategie |

[Annotation: Der 🔴 0 bei Evaluation ist kritisch und korrekt — "nicht erwähnt" = 0, auch wenn man annehmen könnte dass das Team Tests plant. Die Bewertungsregel "Nicht raten" greift hier.]

---

### Phase 3: UX & AI Interaction Design
**Phasen-Score: 1.8 / 3.0**

| Bereich | Score | Bewertung |
|---------|-------|-----------|
| 3.1 AI Design-Prinzipien | 🟡 2 | AI-Summaries als "Vorschläge" gerahmt, Edit-Button vorhanden. Aber: Keine Confidence-Signalisierung, kein Reasoning-Panel |
| 3.2 Progressive Disclosure | 🟡 2 | 2-Ebenen-Disclosure (Basis-View → Detail-View) beschrieben |
| 3.3 Trust Calibration | 🟠 1 | "AI-generiert"-Badge erwähnt. Aber: Keine Fähigkeits-/Limitierungskommunikation, keine Performance-Statistiken |
| 3.4 Graceful Degradation | 🟡 2 | Fallback auf manuelles Summary-Schreiben definiert. Error-Messages in Klartext. Kein Context-Preserving über Fehler hinweg |
| 3.5 Onboarding & TTV | 🟡 2 | "Aha-Moment" identifiziert (erstes AI-Summary), 3-Schritte-Walkthrough. Keine Personalisierung nach Rolle |

---

### Phase 4: Safety, Guardrails & Compliance
**Phasen-Score: 0.4 / 3.0**

| Bereich | Score | Bewertung |
|---------|-------|-----------|
| 4.1 Input Guardrails | 🔴 0 | Nicht adressiert |
| 4.2 Output Guardrails | 🔴 0 | Nicht adressiert |
| 4.3 Human-in-the-Loop | 🟠 1 | "Nutzer kann AI-Output editieren" erwähnt — das ist User Control, kein systematisches HITL. Keine Escalation Rules, keine Tiered Thresholds |
| 4.4 Halluzinations-Mgmt | 🟠 1 | RAG erwähnt als Mitigationsstrategie. Keine Halluzinationsrate definiert, keine Citations, kein Feedback-Mechanismus |
| 4.5 EU AI Act | 🔴 0 | Nicht adressiert. Produkt verarbeitet EU-Nutzerdaten — Klassifikation ist Pflicht |
| 4.6 DSGVO | 🟠 1 | "DSGVO-konform" als Ziel genannt. Aber: Keine Rechtsgrundlage spezifiziert, kein DPA mit Anthropic/OpenAI erwähnt, keine DPIA |
| 4.7 Responsible AI | 🔴 0 | Nicht adressiert |

[Annotation: Diese Phase zeigt das typische Pattern "AI als Feature-Layer" — das Team hat vergessen dass AI eigene Safety-Anforderungen hat. Der Score 0.4 ist alarmierend und der wichtigste Handlungsbedarf.]

---

### Phase 5: Architecture & Infrastructure
**Phasen-Score: 1.9 / 3.0**

| Bereich | Score | Bewertung |
|---------|-------|-----------|
| 5.1 System-Architektur | 🟢 3 | Modular Monolith + Inference-Service, Multi-Tenant mit Row-Level Security, dokumentiert mit Begründung |
| 5.2 AI Gateway | 🟠 1 | Direkte API-Calls an LLM-Provider. Kein Gateway, kein Routing, kein Failover |
| 5.3 Streaming & Latenz | 🟡 2 | SSE für AI-Responses, TTFT-Target <500ms definiert. Kein Backpressure-Handling |
| 5.4 Caching & Kosten | 🟠 1 | Redis für App-Caching. Kein Prefix Caching, kein Semantic Caching, kein Token-Tracking |
| 5.5 Error Handling | 🟡 2 | Retry mit Backoff, Model Fallback. Kein Circuit Breaker, keine Graceful-Degradation-Kaskade |
| 5.6 Monitoring | 🟡 2 | Datadog für Metrics/Logs/Traces. Kein AI-spezifisches Monitoring (Token-Kosten, Confidence, Drift) |
| 5.7 CI/CD | 🟡 2 | GitHub Actions mit Unit/Integration Tests. Keine Prompt-Evaluation im CI. Keine Quality Gates für LLM |
| 5.8 Security | 🟠 1 | TLS 1.3, Auth0 für Auth. Kein Audit Logging für AI-Interaktionen, keine SAST/DAST, kein SOC-2-Plan |

---

### Phase 6: Go-to-Market & Operations
**Phasen-Score: 1.3 / 3.0**

| Bereich | Score | Bewertung |
|---------|-------|-----------|
| 6.1 Rollout-Strategie | 🟡 2 | Alpha → Beta → GA definiert, Feature Flags vorhanden. Kein A/B-Test geplant, keine Rollback-Trigger |
| 6.2 Feedback & Improvement | 🟠 1 | "Feedback-Button" erwähnt. Keine impliziten Signale, keine Improvement-Kadenz, kein Data Flywheel |
| 6.3 Retention & CS | 🟠 1 | MRR-Tracking geplant. Keine NRR-Ziele, keine Churn-Signale, keine Health Scores |
| 6.4 SaaS-Metriken | 🟠 1 | MRR und Churn als Basis-Metriken. Keine Red-Flag-Schwellwerte, kein Puls-Check-Rhythmus |

---

## Teil 3: Gap-Analyse

### 🔴 Kritisch

**Guardrails fehlen komplett** (4.1 + 4.2)  
Die Spec hat weder Input- noch Output-Guards. Bei einem AI-Produkt das Projektdaten verarbeitet ist Prompt Injection ein reales Risiko (OWASP #1). PII-Leakage aus Projektdaten ist ebenfalls unmitigiert.  
→ Definiere mindestens: Prompt Injection Detection, PII-Redaction (Input), Toxicity Filter + PII-Leakage-Check (Output).

**Keine Evaluation/Testing-Strategie** (2.5)  
Ohne Golden Dataset und Eval-Framework ist Qualitätssicherung unmöglich. Prompt-Änderungen können die Output-Qualität unbemerkt degradieren.  
→ Erstelle Golden Dataset (10-20 Beispiele), wähle Eval-Framework (RAGAS oder DeepEval), integriere in CI/CD.

**EU AI Act nicht adressiert** (4.5)  
Produkt operiert in der EU. AI-Literacy-Pflicht und Transparenzpflicht gelten seit Feb 2025. Ohne Klassifikation ist unklar welche weiteren Pflichten bestehen.  
→ Klassifiziere das System (wahrscheinlich: Limited Risk). Dokumentiere Transparenz-Maßnahmen. Prüfe GPAI-Pflichten für verwendete Foundation Models.

### 🟠 Hoch

**AI-Kosten nicht durchkalkuliert** (1.2)  
Hybrid-Pricing definiert AI-Credits, aber Kosten pro AI-Interaktion sind unbekannt. Risiko: Margin-Erosion bei AI-Heavy-Nutzern.  
→ Token-Kosten pro Use Case kalkulieren. Cost per successful task als KPI definieren.

**Kein AI Gateway** (5.2)  
Direkte API-Calls ohne Routing, Failover oder Observability. Single Point of Failure bei Provider-Ausfall.  
→ LiteLLM oder Portkey als Gateway einführen. Model Fallback Chain definieren.

**HITL ist nur User Control** (4.3)  
"Nutzer kann editieren" ist notwendig aber nicht ausreichend. Kein Confidence-basiertes Routing, keine Escalation-Regeln.  
→ Confidence-Thresholds definieren (<70% → manuelles Review). HITL-Pattern (Confidence-Routing) implementieren.

### 🟡 Medium

**RAG-Strategie vage** (2.2) → Advanced RAG (Hybrid Search + Reranking) spezifizieren.  
**Kein AI-Monitoring** (5.6) → Token-Kosten, Confidence-Verteilung, Drift in Datadog ergänzen.  
**Prompt nicht versioniert** (2.3) → SemVer, dediziertes `prompts/` Verzeichnis, Audit Trail.

---

## Teil 4: Priorisierte Handlungsempfehlungen

| # | Maßnahme | Phase | Impact | Aufwand | Priorität |
|---|----------|-------|--------|---------|-----------|
| 1 | Input/Output Guardrails definieren (Prompt Injection, PII, Toxicity) | 4 | Hoch | Mittel | 🔴 Sofort |
| 2 | EU AI Act Klassifikation durchführen + Transparenz-Maßnahmen dokumentieren | 4 | Hoch | Niedrig | 🔴 Sofort |
| 3 | Golden Dataset erstellen + Eval-Framework wählen (DeepEval empfohlen) | 2 | Hoch | Mittel | 🔴 Sofort |
| 4 | DPA mit Anthropic/OpenAI abschließen, Rechtsgrundlage dokumentieren | 4 | Hoch | Niedrig | 🔴 Sofort |
| 5 | AI-Kosten pro Interaktion kalkulieren, Token-Budget pro User-Tier definieren | 1 | Hoch | Niedrig | 🟠 Kurzfristig |
| 6 | AI Gateway einführen (LiteLLM) + Model Fallback Chain | 5 | Hoch | Mittel | 🟠 Kurzfristig |
| 7 | HITL mit Confidence-Routing implementieren (Tiered Thresholds) | 4 | Hoch | Mittel | 🟠 Kurzfristig |
| 8 | RAG auf Advanced-Level spezifizieren (Hybrid Search, Reranking, Chunking) | 2 | Mittel | Mittel | 🟠 Kurzfristig |
| 9 | Prompt-Versionierung einführen (SemVer, `prompts/` Dir, GitOps) | 2 | Mittel | Niedrig | 🟡 Mittelfristig |
| 10 | AI-spezifisches Monitoring ergänzen (Token-Kosten, Confidence, Drift) | 5 | Mittel | Niedrig | 🟡 Mittelfristig |
| 11 | Responsible AI Checklist erarbeiten (Fairness, Accountability, Red-Teaming) | 4 | Mittel | Mittel | 🟡 Mittelfristig |
| 12 | NRR-Ziele, Health Scores, Puls-Check-Kadenz definieren | 6 | Mittel | Niedrig | ⚪ Backlog |

---

> **Annotations-Zusammenfassung** (nur in diesem Beispiel-Report):
>
> Worauf der Auditor besonders achten sollte:
> - **🔴 0 konsequent vergeben** wenn etwas nicht erwähnt wird. Nicht raten.
> - **"Erwähnt" ≠ "Adressiert"**: "Wir werden DSGVO-konform sein" ist 🟠 1, nicht 🟡 2.
>   Erst konkrete Maßnahmen (Rechtsgrundlage, DPA, DPIA) ergeben 🟡 2+.
> - **AI-spezifisch denken**: "Nutzer kann editieren" ist Standard-UX, nicht HITL.
>   HITL erfordert systematische Confidence-basierte Routing und Escalation.
> - **Immer konkrete Maßnahmen**: Nicht "Guardrails verbessern" sondern
>   "Prompt Injection Detection + PII-Redaction als Input Guards definieren".
> - **Phase 4 ist der häufigste Schwachpunkt**: Die meisten AI-SaaS-Specs
>   behandeln Safety als Nachgedanken. Der Auditor sollte hier besonders gründlich sein.
