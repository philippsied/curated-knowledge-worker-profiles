# Referenz 05: Safety, Guardrails, HITL & Compliance

Konsolidiert aus: "AI-SaaS Design-Manifest" §5 (Security/DSGVO), §7 (HITL/Automation) + PRD-Template Parts 3, 6

---

## Content Moderation & Safety Module

### Input Guards
| Guard | Implementierung |
|-------|----------------|
| Prompt Injection Detection | Dedizierter Classifier + Input Sanitization |
| PII Detection/Redaction | NER Model / Regex / Presidio |
| Content Filtering | Toxisch/schädlich — Classifier oder Rule-based |
| Topic Boundaries | Erlaubte/gesperrte Themen-Listen |
| Input Length Validation | Max Tokens |

### Output Guards
| Guard | Monitoring |
|-------|-----------|
| Toxicity/Harm Filtering | Block Rate, False Positive Rate |
| Factual Grounding Check | Groundedness Rate |
| Format Validation | Parse Failure Rate |
| PII Leakage Detection | PII Exposure Rate |
| Confidence Thresholding | Suppression Rate |

### Tools
- **NVIDIA NeMo Guardrails**: Colang-Sprache, +33% Policy-Violation Detection
- **Guardrails AI**: 100+ Validators, On-Fail-Policies (Reask, Fix, Filter, Exception)

### Guardrail Testing
- Adversarial Test Suite bei jedem Prompt/Model-Change
- Red-Teaming vor Beta / quartalsweise
- Bypass-Rate Target: <X%

---

## Human-in-the-Loop Patterns

### 5 Patterns

| Pattern | Beschreibung | Ideal für |
|---------|-------------|-----------|
| **Interrupt/Resume** | Agent pausiert mit `interrupt()`, Mensch gibt Input | Safety-kritische Entscheidungen |
| **Human-as-Tool** | Agent sieht Menschen als callable Tool bei Unsicherheit | Wissenslücken füllen |
| **Confidence-Routing** | Unter Schwellwert → automatisch an Mensch | High-Volume + gelegentliche Edge Cases |
| **Parallel Feedback** | AI pausiert nicht, Feedback asynchron | High-Throughput-Workflows |
| **Elicitation Middleware (MCP)** | Formalisiert als Tool im MCP, traceable, auditierbar | HITL als First-Class-Citizen |

### Tiered Thresholds
| Confidence | Aktion |
|-----------|--------|
| >90% (High) | Auto-Approve |
| 70-90% (Medium) | Spot-Check |
| <70% (Low) | Mandatory Review |

- Kontextabhängig: Höher für High-Stakes, niedriger für Routine
- **Circuit Breaker**: Wenn Error Rate Schwellwert überschreitet → automatisch Manual Review

### Wann HITL zwingend?

**EU AI Act Artikel 14** (High-Risk):
- Verständnis der Systemfähigkeiten und -limitierungen
- Anomalie-Monitoring
- Verhinderung von Automation Bias
- Override- und Stopp-Fähigkeit
- Biometrische Fernidentifikation: mind. 2 kompetente Personen

**Immer HITL bei:**
- Irreversible Aktionen (Datenlöschung, Finanztransaktionen)
- Low-Confidence-Outputs
- Ethische/mehrdeutige Situationen
- Novel/Out-of-Distribution Inputs

### High-Risk-Domains (EU AI Act)
Recruiting, Kreditscoring, Versicherung, Strafverfolgung, Bildung, öffentliche Dienste, Gesundheit, Biometrie.

---

## Progressive Automation: Crawl → Walk → Run

### Crawl (AI als Copilot)
- AI handhabt Basis-Anfragen
- Mensch reviewed, modifiziert, genehmigt jeden Output
- Fokus: Confidence aufbauen, Baseline-Metriken etablieren

### Walk (Erweiterte Autonomie)
- AI direkt an Kunden deployed
- Escalation-Protokolle aktiv
- Kontinuierliches Lernen: Patterns, Wissenslücken, Feedback Loops

### Run (Echte Autonomie)
- AI exekutiert unabhängig
- Mensch: Strategische Aufsicht + Exception Handling
- Nur nach demonstrierter Kompetenz auf vorherigen Leveln

### Principle of Least Autonomy (PoLA)
- Erstes Deployment sollte sich "fast nutzlos konservativ" anfühlen
- Graduelle Subtask-Übergabe, kontingent auf Erfolgsmetriken
- **Readiness-Indikatoren**: Sinkende Error Rate, sinkende Override Rate, stabile CSAT, Edge Case Success

---

## Confidence Scoring

### Problem: LLMs sind systematisch überconfident
- GPT-4o und DeepSeek-R1 clustern bei 90-100% Confidence, Accuracy deutlich niedriger
- RLHF-trainierte Modelle besonders schlecht kalibriert

### 3 Ansätze
1. **Token Log Probabilities**: Direkt, aber oft überconfident
2. **Self-Reported Confidence**: 0-1 Score, interpretierbarer
3. **Simulated Annotators** (ICLR 2025): Simuliert diverse Annotator-Präferenzen, Agreement Ratio = Confidence

---

## Automatisierungsspektrum

| Level | AI-Rolle | Mensch |
|-------|---------|--------|
| 1 Basic | Vordefinierte Sequenzen | Volle Kontrolle |
| 2 Partial | ML-Insights + Empfehlungen | Review + Entscheidung |
| 3 Conditional | Handelt innerhalb Schwellwerten | Supervising |
| 4 High | Komplexe Multi-Step-Ops | Strategische Aufsicht |
| 5 Full | Vollständig selbstständig | Governance + Policy |

McKinsey: 92% steigern AI-Investitionen, nur 1% glaubt AI-Reife erreicht zu haben.

---

## EU AI Act Compliance

### Timeline
| Datum | Pflicht |
|-------|---------|
| **Feb 2025** | Verbotene Praktiken, AI-Literacy |
| **Aug 2025** | GPAI-Model-Pflichten |
| **Aug 2026** | Volle Anwendbarkeit High-Risk |

**Strafen**: Bis €35M oder 7% globaler Umsatz.

### Checkliste nach Klassifikation

**Alle AI-Systeme (seit Feb 2025)**
- [ ] AI-Literacy: Team geschult
- [ ] Transparenz: Nutzer wissen dass sie mit AI interagieren
- [ ] AI-System in internem Inventar registriert

**GPAI-Modelle (seit Aug 2025)**
- [ ] Technische Dokumentation
- [ ] Training Data Summary
- [ ] Copyright Compliance
- [ ] Beschwerde-Mechanismus

**High-Risk (ab Aug 2026)**
- [ ] Risikomanagement-System
- [ ] Data Governance
- [ ] Human Oversight Mechanisms
- [ ] Accuracy, Robustness, Cybersecurity
- [ ] Logging und Record-Keeping
- [ ] Quality Management System
- [ ] Konformitätsbewertung

---

## DSGVO / GDPR für AI-SaaS

### Pflichten
- **DPA nach Art. 28** mit AI-Providern (9 Pflicht-Elemente)
- **DPIA nach Art. 35** für High-Risk Processing
- Zweckbindung und Datenminimierung
- Recht auf Erklärung bei automatisierten Entscheidungen (Art. 22)

### PII-Handling
- Anonymisierung vor LLM-Submission
- Pseudonymisierung mit Fake-Identifiern
- Right to Erasure: Kontextbasierte Verarbeitung (RAM-Flush nach Request)

### AI-spezifische DPA-Klauseln
- Kein Training mit Kundendaten
- Subprocessor-Kette vollständig offengelegt
- Audit-Rechte für AI-spezifische Compliance
- Keine "Function Creep" — Daten nicht für unbeabsichtigte AI-Zwecke

---

## Security

### Prompt Injection = OWASP #1 Risiko (2025)
**Mitigationen:**
- Privilege Control (Least Privilege)
- Strikte Trennung untrusted Content / System-Instruktionen
- Input- und Output-Validierung
- HITL für privilegierte Operationen
- Reguläres adversariales Penetration Testing

### Basis-Security
- Encryption: AES-256 at rest, TLS 1.3 in transit
- Audit Logging: Auth, Admin, Data Access, AI-Interaktionen
- RBAC mit Permission Matrix
- SAST + DAST in CI/CD
- SOC-2 Roadmap (60%+ Enterprise-Kunden fordern es)

---

## Responsible AI Checklist

| Prinzip | Anforderung |
|---------|------------|
| Fairness | Bias-Detection definiert, Tests über demografische Gruppen |
| Transparenz | Erklärbarkeit dokumentiert, AI-Outputs als AI-generiert |
| Accountability | Klare Ownership, Escalation-Paths |
| Safety | Adversarial Robustness, Red-Teaming |
| Privacy | Datenminimierung, Anonymisierung |
| Human Oversight | HITL für High-Stakes, Override-Mechanismus |
| Environmental | Compute-Kosten geschätzt, Effizienz-Optimierungen |
