# Referenz 03: Architecture & Infrastructure

Konsolidiert aus: "AI-SaaS Design-Manifest" §2 (Architektur) + §6 (DevOps)

---

## Architektur-Entscheidung

### Empfehlung: Modular Monolith + Inference-Microservice

| Variante | Eignung | Trade-off |
|----------|---------|-----------|
| Monolith | MVP, <10 Devs | AI-Inferenz nicht unabhängig skalierbar |
| Microservices | Große Teams, unabhängiges Scaling | Enorme operationale Komplexität. Amazon Prime Video: Rollback sparte 90% Infra-Kosten |
| **Modular Monolith** | **Empfohlener Start** | 43% schnellere Feature-Delivery, 22% niedrigere AWS-Kosten (Leap CRM) |

**Entscheidungsregel**: Modular Monolith für Applikationslogik + separater Microservice für AI-Inferenz (GPU-gebunden, latenzsensitiv, andere Skalierung). Services erst extrahieren bei nachgewiesenen Bottlenecks.

---

## Event-Driven Architecture

### Warum EDA für AI-Workloads
- LLM-Inferenz dauert Sekunden bis Minuten — EDA hält Apps responsive
- AI-Workloads sind bursty — EDA skaliert horizontal via Event-Queues
- Bei Model-Failure: Event-gesteuert retry, umleiten, degradieren

### Schlüssel-Patterns
- Multi-Stage AI Processing Pipelines (Upload → OCR → Extraction → Summary)
- Supervisor-orchestrierte Workflows für Multi-Agent
- Event-Driven Agent Meshes (Publish/Subscribe)

### Tools
- **LlamaIndex Workflows**: Event-Driven mit `@step`-Decorator
- **Apache Kafka + Flink**: Real-Time Agentic AI
- **Kestra**: YAML-basierte AI-Workflow-Orchestrierung

**Nicht verwenden** bei simplem Request-Response oder ohne Distributed-Systems-Erfahrung.

---

## AI Gateway

### Funktionen
- Unified API für alle Modelle
- Intelligent Routing (simple → günstig, komplex → teuer)
- Automatisches Failover
- Observability, Security (PII-Masking, Prompt-Injection-Detection)
- Semantic Caching (20-40% Kostenreduktion)
- Streaming-Support

### Tools
| Tool | Fokus |
|------|-------|
| Portkey | Enterprise |
| LiteLLM | Open Source, 100+ Modelle |
| Helicone | Rust, hohe Performance |
| Traefik AI Gateway | Kubernetes-nativ, GitOps |

**Empfehlung**: Sofort einführen, sobald LLM-Nutzung über Experimente hinausgeht.

---

## Streaming: SSE als Standard

- SSE ist De-facto-Standard: unidirektional, HTTP-basiert, Browser-Reconnection
- Nutzer empfinden Streaming als **40% schneller** bei identischer Gesamtzeit
- WebSockets nur für bidirektionale Anforderungen (kollaborative Editoren, Voice)
- **TTFT-Target**: <250ms Consumer-Apps

### Backpressure
Ref-Based Buffering mit `requestAnimationFrame` Flush-Loop für UI-Updates. Verhindert React Re-Render-Storms.

---

## Caching-Strategien: Multi-Tier

### Tier 1: Provider-Level Prefix Caching
- Anthropic: Cache Reads $0.30/MTok statt $3.00 (90% Einsparung, 85% Latenz)
- OpenAI: Auto-Cache ab 1.024 Tokens, 50% Rabatt
- **Implementierung**: Statischer Content (System-Prompts, Few-Shot) am Anfang, dynamischer am Ende

### Tier 2: Semantic Caching
- 31% der LLM-Queries semantisch ähnlich → Verschwendung ohne Caching
- GPTCache: 61,6-68,8% Hit Rate, >97% Accuracy
- Ideal für Support, FAQ-Bots, Search
- **Nicht verwenden** bei hochpersonalisierten oder kreativen Tasks

### Kombiniert: >80% Einsparungen möglich

---

## Kostenoptimierung

LLM-Kosten fallen ~10x jährlich ("LLMflation"). GPT-4-Level: $20/MTok (2022) → $0.40/MTok (heute).

### Reihenfolge nach ROI
1. **Quick Wins (15-40%)**: Prompt-Optimierung + Provider-Caching
2. **Medium Term (+20-40%)**: Semantic Caching + Model Cascading
3. **Advanced (+30-60%)**: Quantisierung, Custom Engines, Hardware

### Rate Limiting für AI-SaaS
- **Token-basiert**, nicht nur Request-basiert
- Hierarchisch: User → Agent → Task Level
- Cost-Based Throttling auf Dollar-Kosten gemappt
- Algorithmus: Token Bucket (Bursts) oder Sliding Window (fair)
- Immer Headers exponieren: `X-RateLimit-Remaining`, `Retry-After`

---

## Error Handling: Production Pipeline

```
App → Circuit Breaker → Graceful Degradation → Model Fallback → Retry + Backoff → LLM API
```

### Retry-Strategie
- Exponential Backoff mit Jitter
- 2x extra Backoff für 429 (Rate Limit)
- Max 3 Retries pro Modell

### Model Fallback Chain
`claude-sonnet-4 → gpt-4o-mini → gemini-flash`

### Circuit Breaker
Nach Threshold-Failures: keine weiteren Requests, periodisches Half-Open-Testing

### Graceful Degradation Priorität
1. Cached Response Fallback
2. Model Fallback Chain
3. Rule-Based Fallback
4. Canned Responses
→ Niemals rohe API-Errors an Nutzer

---

## Monitoring & Observability

### Drei Säulen
| Säule | Standard | Key Signals |
|-------|---------|-------------|
| Metrics | Prometheus / Datadog | Request Rate, Error Rate, Latency P50/P95/P99 |
| Logs | ELK / Datadog | Structured JSON, centralized |
| Traces | OpenTelemetry / Jaeger | Distributed Traces |

### AI-spezifisches Monitoring
- Inference-Latenz (TTFT, Tokens/sec, E2E)
- Token-Nutzung und Cost pro Request/Feature/User
- Confidence-Verteilung
- Guardrail Trigger Rates
- Drift Detection (PSI, KL Divergence)
- User Feedback Sentiment Trends

### Tool-Vergleich
| Tool | Stärke |
|------|--------|
| LangSmith | Tiefes LangChain-Debugging |
| Langfuse | Open Source + Prompt Management |
| Helicone | <1ms P99, integriertes Caching |
| Arize Phoenix | OpenTelemetry, Framework-agnostisch |

### Alerting Tiers
| Severity | Response Time | Beispiel |
|----------|--------------|---------|
| P0 Critical | <15 min | Service down, Data loss |
| P1 High | <1 hour | Degraded performance, AI accuracy drop |
| P2 Medium | <4 hours | Approaching capacity |
| P3 Low | Next business day | Unusual patterns |

---

## CI/CD mit LLM Evaluation

### Vollständige Pipeline
```
PR Created
  ↓ Code Quality (Lint, Types, Unit Tests)
  ↓ Prompt Evaluation (Promptfoo vs. Golden Datasets)
  ↓ Security Scan (Promptfoo Redteam)
  ↓ LLM Regression (DeepEval Suite vs. Baselines)
  ↓ Quality Gate (Fail wenn Pass Rate < 80%)
  ↓ Human Review
  ↓ Merge
  ↓ Build & Push Container
  ↓ GitOps → ArgoCD → Canary Deployment
  ↓ Monitor 30min → Auto-Promote oder Rollback
```

### Prompt Evaluation in CI
- Promptfoo GitHub Action: Built-in Caching, PR-Comment, `pass-rate-threshold`
- DeepEval: Pytest-Integration, semantische + faktuelle + Safety-Checks

### Golden Dataset
- Start mit 10-20 High-Priority-Beispielen (kritische Use Cases + Edge Cases)
- CSV/JSON im Repository
- Über Zeit aus Production Issues erweitern
- Temperature=0 für faktuelle Tests, Semantic Similarity für Style

### GitOps Prompt Management
1. `prompt/*` Branch erstellen
2. CI triggert Evaluationen
3. Ergebnisse als PR-Comment
4. Team reviewed Prompt-Diff + Eval-Ergebnisse
5. Quality Gate blockt bei Degradation
6. Nach Merge: Automatisiertes Deployment

### ArgoCD für AI-Services
- Canary: 10% → 25% → 50% → 100%
- Analysis Templates prüfen LLM-Quality-Metriken
- Auto-Rollback bei P99-Latenz-Überschreitung oder Quality-Drop

### Branching für AI-SaaS
- `main`: Production-Ready
- `feature/*`: Feature-Entwicklung
- `prompt/*`: Prompt-Änderungen (separate Eval-Pipelines)
- `experiment/*`: Model-Swaps, Hyperparameter

### CLAUDE.md als Konfigurationshebel
- Automatisch gelesen bei Session-Start
- Ziel: <200 Zeilen (<60 nach HumanLayer)
- Inhalt: Commands, Code-Style, Architektur, Test-Instruktionen
- In Git committen für Team-Konsistenz
- Progressive Disclosure: Verweise auf separate Docs statt alles reinpacken
