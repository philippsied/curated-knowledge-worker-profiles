# AI-SaaS Gold-Standard Audit-Checkliste

Diese Checkliste konsolidiert Best Practices aus Google PAIR, Microsoft HAX,
Apple HIG, Anthropic, a16z, McKinsey und aktueller Forschung (2024-2026).

Jedes Item ist markiert mit:
- **P0** = Must-Have (Launch-Blocker)
- **P1** = Should-Have (Standard für Produktionsreife)
- **P2** = Could-Have (Differenzierung / Gold Standard)

---

## Phase 1: Strategic Foundation

### 1.1 Problem & Market Validation
- [ ] P0 — Klar definiertes Nutzerproblem mit Evidenz (Interviews, Daten, Tickets)
- [ ] P0 — Ideal Customer Profile (ICP) spezifiziert
- [ ] P0 — Value Hypothesis formuliert und testbar
- [ ] P1 — TAM/SAM/SOM Marktgrößenanalyse vorhanden
- [ ] P1 — Jobs-to-be-Done oder vergleichbares Framework angewendet
- [ ] P1 — Wettbewerbsanalyse mit Differenzierungsstrategie
- [ ] P2 — Sean-Ellis-Test geplant oder durchgeführt (Ziel: ≥40% "sehr enttäuscht")
- [ ] P2 — PMF-Indikatoren definiert (Churn <2%, DAU/MAU >40%, organischer Anteil >30%)

### 1.2 Pricing & Monetarisierung
- [ ] P0 — Pricing-Modell definiert (Freemium, Per-User, Usage-Based, Hybrid)
- [ ] P1 — Wertbasiertes Pricing statt Cost-Plus
- [ ] P1 — Mindestens zwei Preis-Tiers definiert
- [ ] P1 — AI-Kosten pro Interaktion kalkuliert und in Pricing reflektiert
- [ ] P2 — Usage-Based-Elemente für AI-Features integriert
- [ ] P2 — Jährliche Vertragsoption mit Rabatt (Benchmark: ~28%)
- [ ] P2 — Pricing-Review-Kadenz definiert (mindestens halbjährlich)

### 1.3 North Star Metric & Erfolgsmessung
- [ ] P0 — Primary Success Metrics definiert mit Zielwerten
- [ ] P0 — Guardrail Metrics definiert (dürfen sich nicht verschlechtern)
- [ ] P1 — North Star Metric identifiziert (treibt Revenue, reflektiert Kundenwert)
- [ ] P1 — Leading vs. Lagging Indicators unterschieden
- [ ] P1 — Messmethoden und Tools spezifiziert
- [ ] P2 — Metriken nach Minimum / Target / Stretch differenziert
- [ ] P2 — Abort Conditions definiert (automatischer Rollback bei Schwellwert-Verletzung)

---

## Phase 2: AI/ML Core

### 2.1 Model Strategy
- [ ] P0 — Model-Wahl mit Begründung (Accuracy vs. Latency vs. Cost)
- [ ] P0 — Fallback-Model definiert
- [ ] P1 — Model Evaluation Matrix (mind. 2-3 Modelle verglichen)
- [ ] P1 — Multi-Model-Strategie (Routing nach Komplexität: günstig → mid → premium)
- [ ] P1 — Vendor-Lock-in-Risiko bewertet mit Mitigation (Abstraction Layer)
- [ ] P2 — Model Cascading implementiert (einfache Queries → günstige Modelle)
- [ ] P2 — Open-Source vs. Proprietary Trade-off dokumentiert

### 2.2 RAG & Knowledge Architecture
- [ ] P0 — RAG-Ansatz spezifiziert (Naive/Advanced/Graph/Agentic) mit Begründung
- [ ] P0 — Chunking-Strategie definiert (Ziel: 300-500 Tokens)
- [ ] P1 — Hybrid Search (Vektor + BM25) vorgesehen
- [ ] P1 — Reranking-Schritt eingeplant (z.B. Cross-Encoder)
- [ ] P1 — Vektor-DB gewählt mit Begründung
- [ ] P2 — Query Transformation (z.B. HyDE) für mehrdeutige Queries
- [ ] P2 — Parent Document Retrieval (kleine Chunks matchen, große für Kontext)
- [ ] P2 — Retrieval-Latenz-Target definiert (<50ms)

### 2.3 Prompt Engineering
- [ ] P0 — System-Prompt versioniert (Semantic Versioning)
- [ ] P1 — Prompt-Architektur dokumentiert (Strategy, Context Injection, Output Format)
- [ ] P1 — Prompts in dediziertem Verzeichnis, nicht hardcoded
- [ ] P1 — Temperature und Max Tokens mit Begründung gewählt
- [ ] P2 — Prompt-Versioning-Convention (Major/Minor/Patch) definiert
- [ ] P2 — Prompts als immutable Artefakte mit Audit Trail
- [ ] P2 — Prompt-Änderungen von Code-Deployments entkoppelt

### 2.4 Agent & Orchestration
- [ ] P1 — Entscheidung Single Agent vs. Multi-Agent dokumentiert
- [ ] P1 — Orchestration-Framework gewählt (LangGraph, CrewAI, etc.)
- [ ] P1 — State Management mit Checkpointing spezifiziert
- [ ] P2 — Tool Integration über Schema-basierte Function Calls
- [ ] P2 — Supervisor-Pattern für Multi-Agent-Szenarien

### 2.5 Evaluation & Testing
- [ ] P0 — Evaluation-Framework definiert (RAGAS, DeepEval, Promptfoo)
- [ ] P0 — Golden Dataset vorhanden (mind. 10-20 High-Priority-Beispiele)
- [ ] P1 — Automatisierte Eval in CI/CD-Pipeline integriert
- [ ] P1 — Quality Gate mit Pass Rate Threshold (z.B. ≥80%)
- [ ] P1 — Vier-Schichten-Testarchitektur (Unit, Integration, Evaluation, Shadow)
- [ ] P2 — LLM-as-Judge für nicht-deterministische Outputs
- [ ] P2 — Probabilistische Pass Rates (N Runs, X% Erfolg)
- [ ] P2 — Shadow Testing (neuer Prompt parallel zu Production)

---

## Phase 3: UX & AI Interaction Design

### 3.1 AI Design-Prinzipien
- [ ] P0 — AI-Outputs als Vorschläge gerahmt, nicht als Fakten
- [ ] P0 — Confidence-Signalisierung bei AI-Outputs (Scores, Quellen, Reasoning)
- [ ] P0 — Nutzer kann AI-Ergebnisse editieren/ablehnen/regenerieren
- [ ] P1 — Draft-basierte Interfaces statt Black-Box-Automatisierung
- [ ] P1 — Tool-artige Sprache ("Analyse suggests") statt Vermenschlichung ("I think")
- [ ] P2 — Einklappbare Reasoning-Panels für Erklärbarkeit
- [ ] P2 — Versionshistorie für AI-generierte Inhalte

### 3.2 Progressive Disclosure
- [ ] P0 — Einfache Features zuerst, fortgeschrittene bei Bedarf
- [ ] P1 — Maximal 2-3 Disclosure-Ebenen
- [ ] P1 — Klare Indikation wie man auf mehr Optionen zugreift
- [ ] P2 — Tailoring nach Nutzersegment (Experten sehen mehr)

### 3.3 Trust Calibration
- [ ] P0 — Explizite Kommunikation von Fähigkeiten und Limitierungen
- [ ] P1 — Performance-Statistiken vor erster Interaktion zeigen
- [ ] P1 — Confidence-Prozentsätze statt vager Hedgings
- [ ] P2 — Kalibrierung in Early Phases (erste Eindrücke formen Vertrauen persistent)

### 3.4 Graceful Degradation
- [ ] P0 — Funktionierende Basis-Features wenn AI-Services ausfallen
- [ ] P0 — Klartext-Fehlermeldungen statt technischer Codes
- [ ] P1 — 2-3 Recovery-Optionen (Retry, Warten, Alternative)
- [ ] P1 — Nutzerkontext über Fehler hinweg bewahren
- [ ] P1 — Bestätigung dass Nutzerarbeit gespeichert ist
- [ ] P2 — Warme Farben (Amber) statt aggressivem Rot für AI-Fehler

### 3.5 Onboarding & Time-to-Value
- [ ] P0 — Aktivierungsmetrik definiert (erster Wertmoment)
- [ ] P0 — Onboarding-Flow für AI-Features vorhanden
- [ ] P1 — 3-Phasen-Onboarding (60s Orientierung, 1-5min Aktivierung, 5min-7d Verstärkung)
- [ ] P1 — Personalisierter Onboarding-Flow nach Rolle/Segment
- [ ] P2 — "Aha-Moment" identifiziert und optimiert
- [ ] P2 — Dreistufige Tours (72% Completion) statt lange Flows (16%)

---

## Phase 4: Safety, Guardrails & Compliance

### 4.1 Input Guardrails
- [ ] P0 — Prompt Injection Detection implementiert (OWASP #1 Risiko)
- [ ] P0 — PII-Detection und Redaction vor LLM-Submission
- [ ] P1 — Content Filtering (toxisch/schädlich)
- [ ] P1 — Input-Längen-Validierung
- [ ] P1 — Topic Boundaries (erlaubte/gesperrte Themen)
- [ ] P2 — Strikte Trennung von untrusted Content und System-Instruktionen

### 4.2 Output Guardrails
- [ ] P0 — Toxicity/Harm Filtering auf Outputs
- [ ] P0 — PII-Leakage-Detection auf Outputs
- [ ] P1 — Factual Grounding Check (RAG Cross-Reference)
- [ ] P1 — Format-Validierung (JSON Schema Enforcement)
- [ ] P1 — Confidence Thresholding (unter Schwellwert unterdrücken)
- [ ] P2 — Guardrail-Bypass-Rate Target definiert (<X%)

### 4.3 Human-in-the-Loop
- [ ] P0 — HITL-Pattern definiert (Interrupt/Resume, Confidence-Routing, etc.)
- [ ] P0 — Escalation-Regeln spezifiziert (Confidence < Threshold, sensitive Themen)
- [ ] P1 — Tiered Thresholds (>90% Auto-Approve, 70-90% Spot-Check, <70% Review)
- [ ] P1 — Audit Trail für alle HITL-Entscheidungen
- [ ] P2 — Progressive Automation (Crawl → Walk → Run) geplant
- [ ] P2 — PoLA (Principle of Least Autonomy) bei Erstdeployment

### 4.4 Halluzinations-Management
- [ ] P0 — Halluzinations-Strategie definiert (RAG, Citations, Confidence)
- [ ] P0 — Maximale akzeptable Halluzinationsrate festgelegt
- [ ] P1 — Quellen-Citations bei faktischen Claims
- [ ] P1 — "Ich weiß es nicht"-Fähigkeit (Abstention Training)
- [ ] P1 — User Feedback-Mechanismus (Thumbs Up/Down + strukturierte Korrektur)
- [ ] P2 — Multi-Strategy: RAG + CoT + Self-Consistency + Low Temperature

### 4.5 EU AI Act Compliance
- [ ] P0 — Risikokategorie klassifiziert (Minimal/Limited/High/Unacceptable)
- [ ] P0 — AI-Literacy: Team geschult in AI-Fähigkeiten und -Limitierungen (seit Feb 2025)
- [ ] P0 — Transparenz: Nutzer informiert dass sie mit AI interagieren (seit Feb 2025)
- [ ] P1 — GPAI-Model-Pflichten erfüllt (Techn. Doku, Training Data Summary — seit Aug 2025)
- [ ] P1 — Timeline für High-Risk-Anforderungen (ab Aug 2026) dokumentiert
- [ ] P2 — Risikomanagement-System etabliert (für High-Risk)
- [ ] P2 — Konformitätsbewertung geplant (für High-Risk)

### 4.6 DSGVO / GDPR
- [ ] P0 — Rechtsgrundlage für Datenverarbeitung definiert
- [ ] P0 — Data Processing Agreements mit AI-Providern (Art. 28)
- [ ] P1 — DPIA durchgeführt oder geplant (Art. 35)
- [ ] P1 — Datenminimierung verifiziert
- [ ] P1 — Recht auf Erklärung automatisierter Entscheidungen (Art. 22)
- [ ] P1 — Datenschutzerklärung inkludiert AI-Verarbeitung
- [ ] P2 — AI-spezifische DPA-Klauseln (kein Training mit Kundendaten, Subprocessor-Kette)

### 4.7 Responsible AI
- [ ] P1 — Fairness: Bias-Detection-Methodik definiert
- [ ] P1 — Transparenz: AI-Outputs als AI-generiert gekennzeichnet
- [ ] P1 — Accountability: Klare Ownership für AI-Outcomes
- [ ] P2 — Red-Teaming-Session geplant (vor Beta / quartalsweise)
- [ ] P2 — Adversarial Test Suite vorhanden

---

## Phase 5: Architecture & Infrastructure

### 5.1 System-Architektur
- [ ] P0 — Architektur-Entscheidung dokumentiert (Monolith/Modular Monolith/Microservices)
- [ ] P0 — AI-Inferenz als separater Service geplant
- [ ] P1 — Event-Driven Architecture für async AI-Workflows
- [ ] P1 — Multi-Tenant-Design spezifiziert
- [ ] P2 — Modular Monolith + separater Inference Microservice (Empfohlener Start)

### 5.2 AI Gateway
- [ ] P1 — AI Gateway eingeplant (Unified API, Routing, Failover, Observability)
- [ ] P1 — Model Fallback Chain definiert (Primary → Secondary → Tertiary)
- [ ] P2 — Intelligent Routing (einfache Queries → günstige Modelle)
- [ ] P2 — PII-Masking und Prompt-Injection-Detection im Gateway

### 5.3 Streaming & Latenz
- [ ] P0 — Streaming-Architektur definiert (SSE empfohlen)
- [ ] P1 — TTFT-Target definiert (<250ms Consumer, <500ms Enterprise)
- [ ] P1 — Backpressure-Handling für UI-Updates
- [ ] P2 — Latenz-Budgets für alle Endpunkte (P50/P95/P99)

### 5.4 Caching & Kostenoptimierung
- [ ] P1 — Provider-Level Prefix Caching aktiviert
- [ ] P1 — AI-Kosten pro Request/Feature/User getrackt
- [ ] P2 — Semantic Caching für wiederkehrende Queries
- [ ] P2 — Token-basiertes Rate Limiting (nicht nur Request-basiert)
- [ ] P2 — Cost-Based Throttling auf Dollar-Kosten gemappt

### 5.5 Error Handling
- [ ] P0 — Production Error Pipeline (Circuit Breaker → Degradation → Fallback → Retry)
- [ ] P0 — Niemals rohe API-Errors an Nutzer
- [ ] P1 — Exponential Backoff mit Jitter für Retries
- [ ] P1 — Circuit Breaker nach Threshold-Failures
- [ ] P1 — Graceful Degradation Prioritäten (Cache → Fallback → Rules → Canned)

### 5.6 Monitoring & Observability
- [ ] P0 — Drei Säulen: Metrics, Logs, Traces
- [ ] P0 — AI-spezifisches Monitoring (Inferenz-Latenz, Token-Nutzung, Confidence-Verteilung)
- [ ] P1 — Alerting nach Severity-Tiers (P0-P3)
- [ ] P1 — Cost Tracking mit Budget-Alerts
- [ ] P1 — Drift Detection (PSI, KL Divergence)
- [ ] P2 — Quality Dashboards mit automatisierten Alerts
- [ ] P2 — Data Flywheel: Feedback → Training → Improvement Loop

### 5.7 CI/CD & DevOps
- [ ] P1 — Prompt Evaluation in CI/CD-Pipeline (Promptfoo/DeepEval)
- [ ] P1 — Security Scan für Prompt-Vulnerabilities
- [ ] P1 — Quality Gate blockt Merge bei Metrik-Degradation
- [ ] P2 — Canary Deployments für Prompt/Model-Rollouts
- [ ] P2 — GitOps-basiertes Prompt Management
- [ ] P2 — Branching: `prompt/*` Branches separat von Code

### 5.8 Security
- [ ] P0 — Encryption at rest (AES-256) und in transit (TLS 1.3)
- [ ] P0 — Audit Logging für Auth, Admin, Data Access, AI-Interaktionen
- [ ] P1 — RBAC mit definierten Rollen und Permission Matrix
- [ ] P1 — Vulnerability Scanning (SAST + DAST) in CI/CD
- [ ] P1 — SOC-2 Roadmap definiert (60%+ Enterprise-Kunden fordern es)
- [ ] P2 — Penetration Testing geplant (jährlich / vor Major Releases)

---

## Phase 6: Go-to-Market & Operations

### 6.1 Rollout-Strategie
- [ ] P0 — Phasen-Rollout definiert (Alpha → Beta → GA)
- [ ] P0 — Feature Flags für Kill Switch und Rollout-Steuerung
- [ ] P1 — Rollback-Trigger und -SLA definiert (Detect+Decide+Disable ≤10min)
- [ ] P1 — A/B-Test: Control (ohne AI) vs. Treatment (mit AI)
- [ ] P2 — Model Validation Phase (Offline-Eval vor Alpha)
- [ ] P2 — Kommunikationsplan je Phase (intern + extern)

### 6.2 Feedback & Continuous Improvement
- [ ] P0 — Explizites Feedback (Thumbs Up/Down, Korrekturen) implementiert
- [ ] P1 — Implizite Signale getrackt (Akzeptanz, Abbruch, Edit-Distance)
- [ ] P1 — Improvement-Kadenz definiert (Weekly Eval, Monthly Review, Quarterly Audit)
- [ ] P2 — Data Flywheel dokumentiert (Feedback → Training → Improvement)
- [ ] P2 — Retraining-Trigger definiert (Accuracy-Drop, Drift, neue Daten)

### 6.3 Retention & Customer Success
- [ ] P1 — NRR-Ziel definiert (>100% für Wachstum)
- [ ] P1 — Churn-Monitoring und -Warnsignale
- [ ] P1 — Aktivierungsrate als Leading Indicator getrackt
- [ ] P2 — Health Score mit 6-12 Datenpunkten
- [ ] P2 — Proaktive Intervention bei Churn-Signalen
- [ ] P2 — Expansion-Trigger bei 80% der Tier-Grenzen

### 6.4 SaaS-Metriken & Anti-Pattern-Erkennung
- [ ] P0 — Basis-Metriken definiert (MRR, Churn, NRR, LTV:CAC)
- [ ] P1 — Red-Flag-Schwellwerte definiert (Churn >5%, NRR <90%, LTV:CAC <1:1)
- [ ] P1 — Wöchentlicher Puls-Check (DAU/WAU, Signups, Aktivierung, Feature-Nutzung)
- [ ] P1 — Premature-Scaling-Guard: PMF nachgewiesen bevor Sales/Marketing skaliert wird
- [ ] P1 — Feature-Bloat-Guard: Priorisierungsframework (RICE/MoSCoW) und Disziplin Nein zu sagen
- [ ] P2 — Leaky-Bucket-Check: Retention-Kurve stabilisiert sich (nicht fallend gegen null)
- [ ] P2 — Rule of 40 und Burn Multiple getrackt
- [ ] P2 — Pricing-Review-Kadenz eingehalten (vgl. Ref 01: 30% höhere Wachstumsraten)

---

## Scoring-Zusammenfassung

| Phase | Bereiche | Max Score |
|-------|---------|-----------|
| 1. Strategic Foundation | 3 Bereiche | 9 |
| 2. AI/ML Core | 5 Bereiche | 15 |
| 3. UX & AI Design | 5 Bereiche | 15 |
| 4. Safety & Compliance | 7 Bereiche | 21 |
| 5. Architecture & Infra | 8 Bereiche | 24 |
| 6. GTM & Operations | 4 Bereiche | 12 |
| **Gesamt** | **32 Bereiche** | **96** |

### Reifegrad-Einstufung

| Score-Range | Reifegrad | Interpretation |
|-------------|-----------|---------------|
| 0–24 (0-25%) | 🔴 Beginner | Fundamentale Lücken, nicht produktionsreif |
| 25–48 (26-50%) | 🟠 Developing | Grundlagen vorhanden, erheblicher Nachholbedarf |
| 49–72 (51-75%) | 🟡 Advanced | Solide Basis, Optimierungspotential in Details |
| 73–96 (76-100%) | 🟢 Gold Standard | Best Practices umfassend implementiert |
