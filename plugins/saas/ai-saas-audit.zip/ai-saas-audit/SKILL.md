---
name: ai-saas-audit
description: >
  Führt ein strukturiertes Gold-Standard-Audit einer AI-SaaS-Spezifikation durch.
  Prüft systematisch in 6 Phasen: (1) Product Strategy & PMF, (2) AI/ML Core,
  (3) UX & AI Interaction Design, (4) Safety, Guardrails & Compliance,
  (5) Architecture & Infrastructure, (6) Go-to-Market & Operations.
  Leitet konkrete Handlungsempfehlungen mit Prioritäten ab.
  Nutze diesen Skill bei: 'Audit', 'SaaS Spezifikation prüfen', 'AI-SaaS Review',
  'Spezifikation bewerten', 'PRD Audit', 'Gold Standard Check', 'AI Product Review',
  'Produkt-Spec analysieren', 'Readiness Assessment', 'Launch Readiness',
  'AI-SaaS Qualitätsprüfung', 'Spec Review', 'Product Audit'.
  Auch auslösen wenn der Nutzer ein PRD, eine Produktspezifikation oder ein
  Konzeptdokument für ein AI-SaaS-Produkt hochlädt und Feedback oder
  Verbesserungsvorschläge wünscht.
---

# AI-SaaS Gold-Standard Audit

Dieses Skill führt ein systematisches Audit einer AI-SaaS-Spezifikation durch.
Es basiert auf konsolidierten Best Practices aus führenden Frameworks (Google PAIR,
Microsoft HAX, Apple HIG, Anthropic), Industrie-Benchmarks und bewährten
Architektur-Patterns.

## Workflow-Überblick

```
INPUT: Spezifikation / PRD / Konzeptdokument

Phase 1: Strategic Foundation   → Ref 01-product-strategy.md
Phase 2: AI/ML Core             → Ref 04-ai-ml-quality.md
Phase 3: UX & AI Design         → Ref 02-ux-ai-design.md
Phase 4: Safety & Compliance    → Ref 05-safety-compliance.md
Phase 5: Architecture & Infra   → Ref 03-architecture-infra.md
Phase 6: GTM & Operations       → Ref 06-prd-reference.md + Ref 01

Synthese: Audit-Scoring + Handlungsempfehlungen

OUTPUT: Audit-Report mit Scores, Gaps und priorisierten Maßnahmen
```

---

## Schritt 0: Kontext erfassen

Bevor du mit dem Audit startest, kläre folgende Fragen mit dem Nutzer:

1. **Was wird geaudited?** — PRD, Konzeptdokument, Feature-Spec, Gesamtprodukt?
2. **In welcher Phase befindet sich das Produkt?** — Ideation, MVP, PMF-Suche, Skalierung?
3. **Welche Audit-Tiefe ist gewünscht?** — Quick-Check (Top-Level Gaps) oder Deep Audit (alle 6 Phasen)?
4. **Gibt es spezifische Fokus-Bereiche?** — z.B. nur Compliance, nur Architektur?
5. **Zielgruppe des Audits?** — Technisches Team, Stakeholder, Investoren?

→ Passe die Audit-Tiefe an die Phase an:
- **Ideation/Pre-MVP**: Fokus auf Phase 1 + 2, Rest als Gap-Identifikation
- **MVP**: Alle Phasen, aber mit MVP-angemessenen Schwellwerten
- **Skalierung**: Volle Tiefe, Enterprise-Benchmarks anwenden

---

## Schritt 1: Spezifikation einlesen und verstehen

Lies die bereitgestellte Spezifikation vollständig. Erstelle ein internes Verständnis:

- Was ist das Produkt? Wer sind die Zielnutzer?
- Welche AI/ML-Capabilities werden beschrieben?
- Welche Abschnitte existieren, welche fehlen?
- Welcher Reifegrad ist erkennbar?

→ Lade die Audit-Checkliste: `references/audit-checklist.md`

### Edge Cases erkennen

Bevor du mit dem phasenweisen Audit startest, prüfe:

**Kein AI-SaaS-Produkt?** Wenn die Spec keine AI/ML-Komponenten enthält,
teile dem Nutzer mit dass die AI-spezifischen Phasen (Phase 2 komplett,
Phase 4 teilweise, AI-Teile von Phase 5) nicht anwendbar sind. Biete an,
die allgemeinen SaaS-Bereiche trotzdem zu prüfen (Phase 1, 3.2-3.5, 5.1,
5.5-5.8, 6). Bewerte AI-Bereiche NICHT mit 🔴 0 — markiere sie als "N/A".

**Unvollständige Spec?** Wenn die Spec nur 1-2 Seiten umfasst und offensichtlich
ein Frühstadium-Dokument ist, empfehle den Quick-Check-Modus und weise darauf hin,
dass viele 🔴 0-Bewertungen dem Reifegrad des Dokuments geschuldet sind, nicht
zwingend dem Reifegrad des Produkts.

**Multi-Produkt-Spec?** Wenn mehrere Produkte/Features in einer Spec beschrieben
werden, kläre mit dem Nutzer welches Produkt/Feature geaudited werden soll.

---

## Schritt 2: Phasenweises Audit durchführen

Für jede der 6 Phasen:

1. Lade die zugehörige Referenz-Datei (siehe Mapping oben)
2. Prüfe die Spezifikation gegen die Checklisten-Items dieser Phase
3. Bewerte jeden Bereich mit dem Scoring-Schema (siehe unten)
4. Dokumentiere Gaps und leite Handlungsempfehlungen ab

### Scoring-Schema

Bewerte jeden Audit-Bereich auf einer 4-stufigen Skala:

| Score | Label | Bedeutung |
|-------|-------|-----------|
| 🔴 0 | Fehlt | Nicht adressiert oder erwähnt |
| 🟠 1 | Unvollständig | Erwähnt aber ohne ausreichende Tiefe oder Konkretisierung |
| 🟡 2 | Solide | Adressiert mit konkreten Angaben, aber Lücken in Best Practices |
| 🟢 3 | Gold Standard | Vollständig adressiert, entspricht oder übertrifft Best Practices |

### Bewertungsregeln

- **Nicht raten**: Wenn die Spezifikation etwas nicht erwähnt, ist es 🔴 0 — nicht 🟡 2 weil es „wahrscheinlich gemeint" war
- **Kontext berücksichtigen**: Ein MVP braucht kein SOC-2, aber eine Aussage zur Security-Roadmap
- **Evidenz fordern**: Metriken ohne Zielwerte = 🟠 1, Metriken mit Zielwerten = 🟡 2, Metriken mit Zielwerten + Messmethode = 🟢 3
- **Phasen-angemessen bewerten**: Pre-MVP Specs werden an Pre-MVP Standards gemessen, nicht an Enterprise-Standards

### Scoring-Aggregation

Die Berechnung folgt einer klaren Kette: Bereich → Phase → Gesamt.

**Bereichs-Score** (0–3): Bewerte jeden der 32 Bereiche (z.B. "2.1 Model Strategy")
anhand der Checklisten-Items. Die Bewertungslogik:
- Sind alle P0-Items erfüllt? Wenn nein → maximal 🟠 1
- Sind alle P0 + mehrheitlich P1-Items erfüllt? → mindestens 🟡 2
- Sind P0 + P1 + mehrheitlich P2 erfüllt? → 🟢 3
- Ist nichts adressiert? → 🔴 0

**Phasen-Score** (0.0–3.0): Arithmetisches Mittel aller Bereichs-Scores dieser Phase.
Beispiel Phase 2 (5 Bereiche): (3 + 3 + 2 + 2 + 0) / 5 = 2.0

**Gesamt-Score**: Summe aller 32 Bereichs-Scores (0–96).
Für den gewichteten Gesamt-Score nach Produktphase multipliziere jeden
Phasen-Score mit dem Gewichtungsfaktor (siehe Tabelle "Anpassung an Produktphase")
und normiere auf 100%.

**Reifegrad-Einstufung** basiert auf dem Gesamt-Score:
- 0–24 (0–25%): 🔴 Beginner
- 25–48 (26–50%): 🟠 Developing
- 49–72 (51–75%): 🟡 Advanced
- 73–96 (76–100%): 🟢 Gold Standard

---

## Schritt 3: Audit-Report erstellen

### Format des Audit-Reports

Der Report besteht aus 4 Teilen:

#### Teil 1: Executive Summary
- Gesamtscore (Durchschnitt aller Phasen)
- Reifegrad-Einschätzung (Beginner / Developing / Advanced / Gold Standard)
- Top-3 Stärken
- Top-3 kritische Gaps
- Gesamteinschätzung in 3-5 Sätzen

#### Teil 2: Phasen-Detail-Scores

Für jede Phase eine Tabelle:

```
## Phase X: [Name]
Phasen-Score: X.X / 3.0

| Bereich | Score | Bewertung |
|---------|-------|-----------|
| [Bereich 1] | 🟢 3 | [Kurzbegründung] |
| [Bereich 2] | 🟠 1 | [Kurzbegründung] |
| ... | ... | ... |
```

#### Teil 3: Gap-Analyse

Gruppiert nach Kritikalität:

**🔴 Kritisch (Score 0 — muss adressiert werden)**
- [Gap]: [Was fehlt] → [Was der Gold Standard verlangt]

**🟠 Hoch (Score 1 — deutliche Verbesserung nötig)**
- [Gap]: [Was unvollständig ist] → [Was konkret ergänzt werden sollte]

**🟡 Medium (Score 2 — Optimierungspotential)**
- [Gap]: [Was solide ist aber besser sein könnte] → [Konkreter Verbesserungsvorschlag]

#### Teil 4: Priorisierte Handlungsempfehlungen

Geordnet nach Impact × Aufwand:

| # | Maßnahme | Phase | Impact | Aufwand | Priorität |
|---|----------|-------|--------|---------|-----------|
| 1 | [Konkrete Maßnahme] | [Phase] | Hoch | Niedrig | 🔴 Sofort |
| 2 | [Konkrete Maßnahme] | [Phase] | Hoch | Mittel | 🟠 Kurzfristig |
| 3 | [Konkrete Maßnahme] | [Phase] | Mittel | Niedrig | 🟡 Mittelfristig |

**Priorisierungsregeln:**
- 🔴 Sofort: Compliance-Blocker, Security-Risiken, fehlende Kern-AI-Spezifikationen
- 🟠 Kurzfristig (nächste 2-4 Wochen): Architektur-Entscheidungen, Metriken-Definition, HITL-Design
- 🟡 Mittelfristig (nächste 1-3 Monate): Optimierungen, erweiterte Testing-Strategien, Advanced Features
- ⚪ Backlog: Nice-to-haves, langfristige Verbesserungen

---

## Schritt 4: Ergebnis präsentieren

### Ausgabeformat

Erstelle den Audit-Report als **Markdown-Datei** (.md) im Outputs-Verzeichnis.

Ergänze den Report um eine visuelle Zusammenfassung (Radar-Chart oder Score-Tabelle)
die den Reifegrad über alle 6 Phasen zeigt.

### Interaktion mit dem Nutzer

Nach der Präsentation des Reports:
1. Frage ob der Nutzer in bestimmte Phasen tiefer einsteigen möchte
2. Biete an, für kritische Gaps konkrete Textvorschläge/Ergänzungen zur Spec zu liefern
3. Biete an, eine priorisierte Aufgabenliste (z.B. für Todoist, Asana) zu erstellen

---

## Referenz-Dateien

Die folgenden Referenz-Dateien enthalten die extrahierten Best Practices
und Benchmarks aus den Research-Reports. Lade sie nach Bedarf:

| Referenz | Inhalt | Primär | Sekundär |
|----------|--------|--------|----------|
| `references/audit-checklist.md` | Vollständige Audit-Checkliste (alle Phasen) | Immer | — |
| `references/example-audit.md` | Annotiertes Beispiel eines fertigen Audit-Reports | Immer | — |
| `references/01-product-strategy.md` | PMF, Pricing, PLG, Metriken, Anti-Patterns, Onboarding-Benchmarks | Phase 1 | Phase 3 (Onboarding), Phase 6 (Metriken, Anti-Patterns) |
| `references/02-ux-ai-design.md` | AI Design-Prinzipien, Trust, Progressive Disclosure, Graceful Degradation | Phase 3 | Phase 4 (Trust ↔ Safety) |
| `references/03-architecture-infra.md` | Architektur-Patterns, Caching, DevOps, CI/CD, Error Handling | Phase 5 | Phase 2 (CI/CD für Prompts) |
| `references/04-ai-ml-quality.md` | RAG, Agents, Model Strategy, Eval, Testing, Quality Metrics | Phase 2 | Phase 4 (Halluzinations-Detection Tools) |
| `references/05-safety-compliance.md` | Guardrails, HITL, EU AI Act, DSGVO, Responsible AI | Phase 4 | Phase 2 (Confidence Scoring), Phase 5 (Security) |
| `references/06-prd-reference.md` | PRD-Struktur, AI-Sections, Rollout, Feature Flags, NFR-Benchmarks | Phase 6 | Phase 2 (Acceptance Criteria), Phase 5 (Performance Budgets) |

---

## Hinweise zur Anwendung

### Dos
- Jede Bewertung mit konkretem Bezug zur Spezifikation begründen
- Bei fehlenden Informationen klar „nicht adressiert" sagen, nicht interpretieren
- Handlungsempfehlungen so konkret formulieren, dass sie direkt umsetzbar sind
- Phase und Reifegrad des Produkts bei der Bewertung berücksichtigen

### Don'ts
- Keine generischen Empfehlungen wie „mehr Tests schreiben"
- Nicht annehmen, dass etwas implementiert ist, nur weil es nicht explizit ausgeschlossen wird
- Keine Bewertung basierend auf impliziten Annahmen
- Nicht alle Phasen gleich gewichten — Reifegrad des Produkts bestimmt die Gewichtung

### Anpassung an Produktphase

| Phase | Gewichtung | Fokus |
|-------|-----------|-------|
| Pre-MVP | Phase 1 (40%), Phase 2 (30%), Rest je 10% | Strategie & AI-Core |
| MVP | Phase 1-3 je 20%, Phase 4-5 je 15%, Phase 6 (10%) | Breite Abdeckung |
| Skalierung | Alle Phasen je ~17% | Gleichmäßig, Enterprise-Standards |

---

## Quick-Check Modus

Wenn der Nutzer einen Quick-Check wünscht (nicht Deep Audit):

1. Lade nur `references/audit-checklist.md`
2. Prüfe nur die **Must-Have**-Items (markiert mit P0) der Checkliste
3. Erstelle einen kompakten Report: Executive Summary + Top-10 Gaps + Top-5 Maßnahmen
4. Biete Deep-Audit als Follow-up an
